---
name: research-analyst
description: "Research and discovery skill. Covers codebase analysis, document import strategies, structured discovery questions, technical research methodology, ecosystem evaluation, and RESEARCH.md production. Use when: starting features, analyzing codebases, importing external docs, resolving unknowns. DO NOT USE for writing specs or code."
---

# Research Analyst Skill

---
**Model:** `claude-sonnet-4-6`
**Chat mode:** Ask
**Extended thinking:** No
**Rationale:** Research is information synthesis, not deep reasoning. Sonnet handles retrieval and summarization well at 1x cost.

---

## 0. Model Routing

| Task | Model | Mode | Extended Thinking |
|------|-------|------|-------------------|
| Full research workflow | `claude-sonnet-4-6` | Ask | No |
| Complex architectural analysis of existing codebase | `claude-opus-4-6` | Ask | Yes |
| Quick codebase scan or ecosystem check | `claude-haiku-4-5` | Ask | No |

---

## 1. Input Triage

Before researching, classify input sources:

| Source | Tool | Priority |
|--------|------|----------|
| Existing codebase | `sdd_scan_codebase` | P0 for brownfield |
| Meeting transcript (VTT/SRT) | `sdd_import_transcript` | P0 if available |
| PRD / requirements doc (PDF/DOCX) | `sdd_import_document` | P0 if available |
| Figma designs | `sdd_figma_to_spec` | P1 if UI-heavy |
| Mixed document folder | `sdd_batch_import` | P1 if multiple docs |
| Developer's verbal description | `sdd_discover` | Always (fills gaps) |

**Rule:** Process all available P0 inputs before running discovery. Discovery questions should be informed by what was already imported.

---

## 2. Codebase Scan Strategy

### When to scan
- Always for brownfield, modernization, legacy-migration
- Always when the developer mentions "existing code", "current system", "add to"
- Skip for greenfield only

### What `sdd_scan_codebase` reveals

| Finding | Impact on Specification |
|---------|----------------------|
| Language/framework detected | Constrains NFRD Technology Stack |
| Database type found | Constrains data model decisions |
| Auth library present | Constrains NFR-02 Security |
| Test framework present | Determines test stub framework |
| CI/CD config found | Constrains NFR-05 CI/CD |
| API framework detected | Determines API doc format |
| Docker/compose found | Determines deployment strategy |

### Pattern recognition

| Pattern | Signal | Implication |
|---------|--------|-------------|
| MVC | `controllers/`, `models/`, `views/` | REST API likely, layer-based design |
| Hexagonal | `ports/`, `adapters/`, `domain/` | Clean architecture, interface-driven design |
| Microservices | Multiple `package.json` or services dirs | Service decomposition needed |
| Monolith | Single large `src/` | Consider modularization in design phase |
| Event-driven | Message queue configs, event handlers | Async patterns needed in spec |

---

## 3. Discovery Question Framework

`sdd_discover` generates 7 questions. Here's the framework behind them:

| Question # | Domain | Why It Matters |
|-----------|--------|---------------|
| 1 | Scope boundaries | Prevents scope creep — what is NOT in this feature |
| 2 | User roles | Determines authorization model and user flows |
| 3 | Constraints | Tech stack, compliance, timeline, budget |
| 4 | Integrations | External systems, APIs, data sources |
| 5 | Performance | Concurrent users, response times, data volume |
| 6 | Security | Auth method, data sensitivity, compliance |
| 7 | Deployment | Cloud/on-prem, environments, CI/CD |

### Good vs bad discovery answers

| Quality | Example |
|---------|---------|
| ✅ Specific | "50 concurrent users, <200ms API response, PostgreSQL 15" |
| ✅ Bounded | "Phase 1 is auth + CRUD. Notifications are Phase 2." |
| ❌ Vague | "It should be fast and secure" |
| ❌ Unbounded | "Everything a user might need" |

When answers are vague, convert them to documented assumptions with consequences:
```
Assumption A1: "Fast" means <200ms p95 API response
Consequence if wrong: Need to re-evaluate caching strategy
```

---

## 4. Research Question Taxonomy

### Good research questions (specific, answerable)

| Category | Example |
|----------|---------|
| Architecture | "What are the tradeoffs between event sourcing and CQRS for this domain?" |
| Performance | "What is the typical latency of {external API} under production load?" |
| Security | "Does {industry} require specific encryption standards beyond TLS 1.3?" |
| Compliance | "What LGPD requirements apply to storing Brazilian user PII?" |
| Integration | "Does {service} provide webhooks or do we need polling?" |
| Ecosystem | "Which MCP servers support {platform} integration?" |

### Bad research questions (avoid)

| Problem | Example | Fix |
|---------|---------|-----|
| Too broad | "What's the best database?" | "What databases support our read/write ratio of 10:1 with <50ms p95?" |
| Opinion-based | "Should we use React?" | "What frontend frameworks match our team's TypeScript expertise?" |
| Already decided | "Is REST better than GraphQL?" (when REST is in constraints) | Skip — it's a constraint, not a question |
| Premature | "How should we implement caching?" | This is a design decision, not research |

---

## 5. Ecosystem Evaluation

### MCP server selection criteria

| Criterion | Weight | How to Evaluate |
|-----------|--------|-----------------|
| Active maintenance | HIGH | Last commit < 3 months, issues responded to |
| Auth model | HIGH | OAuth 2.0 / API key / none |
| Transport | MEDIUM | stdio / HTTP / SSE |
| Tool coverage | MEDIUM | Does it cover the operations we need? |
| Community | LOW | Stars, forks (not decisive but informative) |

### Common ecosystem patterns

| Project Type | Recommended MCP Servers |
|-------------|------------------------|
| API service + GitHub | GitHub MCP + Docker MCP |
| Enterprise app + Azure | Azure DevOps MCP + Terraform MCP (Bicep) |
| UI-heavy + Figma | Figma MCP + GitHub MCP |
| Microservices | Docker MCP + Terraform MCP + GitHub MCP |
| Data platform | Terraform MCP + GitHub MCP |

---

## 6. RESEARCH.md Template

```markdown
---
title: "Research — {Feature Name}"
feature_id: "{NNN-feature-name}"
version: 1.0.0
date: "{YYYY-MM-DD}"
project_type: "{type}"
input_sources: ["{list of sources analyzed}"]
---

# Research — {Feature Name}

## 1. Project Context
{Summarize from CONSTITUTION.md: scope, stakeholders, boundaries, constraints}

## 2. Existing Codebase
{From sdd_scan_codebase or "N/A — greenfield project"}

### Tech Stack Detected
| Component | Technology | Version |
|-----------|-----------|---------|
| {component} | {tech} | {version} |

### Architecture Pattern
{Detected pattern and its implications}

## 3. External Input Summary
{From imported documents/transcripts}

### Source: {document name}
- Key finding 1
- Key finding 2

## 4. Discovery Answers
| # | Question | Answer | Assumption (if vague) |
|---|---------|--------|----------------------|
| 1 | {question} | {answer} | {assumption if needed} |

## 5. Technical Research
### Q1: {question}
**Finding:** {answer with evidence}
**Impact on spec:** {how this affects requirements}

## 6. Ecosystem Recommendations
| MCP Server | Purpose | Install |
|-----------|---------|---------|
| {server} | {why needed} | {install command} |

## 7. Open Questions for Specification
| # | Question | Severity | Recommended Resolution |
|---|---------|----------|----------------------|
| 1 | {question} | CRITICAL/HIGH/LOW | {how to resolve in clarify phase} |

## 8. Research Confidence
| Area | Confidence | Gaps |
|------|-----------|------|
| Tech stack | HIGH/MEDIUM/LOW | {what's uncertain} |
| Performance requirements | HIGH/MEDIUM/LOW | {what's uncertain} |
| Security requirements | HIGH/MEDIUM/LOW | {what's uncertain} |
| Integration points | HIGH/MEDIUM/LOW | {what's uncertain} |
```

---

## 7. Anti-Patterns

| Anti-Pattern | Why It's Wrong | Correct Approach |
|-------------|---------------|------------------|
| Skipping codebase scan for brownfield | Specs that ignore existing code fail at implementation | Always scan existing codebases |
| Writing EARS requirements in research | Research gathers info, spec-engineer writes requirements | Document findings, don't write specs |
| Asking >5 discovery questions at once | Overwhelms the developer, gets superficial answers | 7 structured questions max, wait for answers |
| Researching questions already in constraints | Wastes time and confuses priorities | Skip constrained decisions |
| Importing documents without reading constitution first | No framing context for interpretation | Read CONSTITUTION.md first, then import |
| Proceeding with many unanswered questions | Spec built on assumptions cascades errors | Resolve or explicitly document as open items |
