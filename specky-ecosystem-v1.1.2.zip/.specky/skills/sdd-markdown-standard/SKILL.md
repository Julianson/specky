---
name: sdd-markdown-standard
description: "Formatting standard for all Specky spec artifacts (.specs/*.md). Enforces YAML frontmatter, Change Log, TOC, numbered headings, Mermaid diagrams, and traceability links. Every agent that writes to .specs/ MUST load this skill. Aligned with markdown-writer skill conventions. Use when: any Specky tool writes a .md file to .specs/."
---

# SDD Markdown Standard

---

Every `.md` file in `.specs/NNN-feature/` must follow this standard. This is not optional — it is the formatting contract that enables tooling (frontmatter parsing), traceability (REQ-ID links), and human readability (consistent structure across all 11 artifact types).

This skill is loaded **alongside** the domain-specific skill (e.g., `implementer` loads `sdd-markdown-standard` + `implementer`).

---

## 1. Mandatory YAML Frontmatter

Every artifact starts with this block. No exceptions.

```yaml
---
title: "{Artifact Type} — {Feature Name}"
feature_id: "{NNN-feature-name}"
version: "1.0.0"
date: "{YYYY-MM-DD}"
author: "{author or agent name}"
status: "draft | review | approved"
based_on: "{upstream artifact} (version X.Y.Z)"
phase: "{phase number and name}"
tags: ["{artifact-type}", "{feature-name}", "SDD"]
---
```

### Field Rules

| Field | Required | Format | Example |
|-------|----------|--------|---------|
| `title` | Yes | `{Type} — {Feature}` | `"Specification — User Authentication"` |
| `feature_id` | Yes | `NNN-kebab-case` | `"001-user-authentication"` |
| `version` | Yes | Semver | `"1.0.0"` |
| `date` | Yes | ISO 8601 | `"2026-04-13"` |
| `author` | Yes | Name or agent | `"Paula Silva"` or `"Specky (spec-engineer v3.2)"` |
| `status` | Yes | Enum | `"draft"` / `"review"` / `"approved"` |
| `based_on` | Yes (except CONSTITUTION) | Upstream reference | `"SPECIFICATION.md (version 1.0.0)"` |
| `phase` | Yes | Number + name | `"3 — Specify"` |
| `tags` | Yes | Array | `["specification", "001-user-auth", "SDD"]` |

### Version Bumping

| Change | Bump | Example |
|--------|------|---------|
| Initial creation | 1.0.0 | First write of SPECIFICATION.md |
| Clarification applied | 1.1.0 | After /sdd:clarify updates requirements |
| Typo/formatting fix | 1.0.1 | Minor correction, no content change |
| Major scope change via sdd_amend | 2.0.0 | CONSTITUTION.md scope change cascades |

---

## 2. Document Structure (all 11 artifacts)

```markdown
---
[frontmatter]
---

# {Artifact Type} — {Feature Name}

> {One-sentence purpose of this document.}

## Change Log

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | {date} | {author} | Initial version |

## Table of Contents

- [1. Section Name](#1-section-name)
- [2. Section Name](#2-section-name)
  - [2.1 Subsection](#21-subsection)

---

## 1. {First Section}

{content}

## 2. {Second Section}

{content}

---

## References

- [CONSTITUTION.md](./CONSTITUTION.md)
- [SPECIFICATION.md](./SPECIFICATION.md)
```

### Heading Rules

- `# H1` — document title only (exactly one)
- `## H2` — major sections, numbered: `## 1. Introduction`
- `### H3` — subsections, numbered: `### 1.1 Overview`
- `#### H4` — use sparingly
- Never skip heading levels

### TOC Rules

- Required when document has >3 H2 sections
- Use markdown links: `- [1. Section](#1-section)`
- Must match actual headings exactly

---

## 3. Per-Artifact Format

### CONSTITUTION.md (Phase 0 — Init)

```yaml
title: "Constitution — {Feature Name}"
phase: "0 — Init"
based_on: "FRD + NFRD (if available)"
```

| Section | Required | Content |
|---------|----------|---------|
| Article 1: Purpose | Yes | What this feature does, who it serves |
| Article 2: Scope | Yes | In scope (explicit list) + Out of scope (min 3 items) |
| Article 3: Principles | Yes | Naming, architecture, testing, error handling |
| Article 4: Quality Standards | Yes | Test coverage, response format, character limit |
| Article 5: Amendment Protocol | Yes | How to change via sdd_amend |
| Article 6: Scope Boundaries | Yes | In scope vs out of scope (definitive list) |

---

### SPECIFICATION.md (Phase 3 — Specify)

```yaml
title: "Specification — {Feature Name}"
phase: "3 — Specify"
based_on: "CONSTITUTION.md (version X.Y.Z)"
```

| Section | Required | Content |
|---------|----------|---------|
| System Overview | Yes | What, who, why — no tech stack |
| Stakeholder Roles | Yes | Table: Role / Description / Key Permissions |
| Domain Sections | Yes | One ## per domain, requirements with EARS notation |
| Requirements Summary | Yes | Table: ID / Title / Domain / Priority / Phase |
| Implementation Phases | Yes | Phase grouping of requirements |

**EARS Requirement Format:**

```markdown
### REQ-{DOMAIN}-{NN}: {Title} — Priority P{0-3}

{EARS pattern: The system shall... / When X, the system shall... / etc.}

1. {Behavior 1}
2. {Behavior 2}

**Acceptance signal:** {observable, testable check}
**Traces to:** {CONSTITUTION article or principle}
```

---

### RESEARCH.md (Phase 1 — Research)

```yaml
title: "Research — {Feature Name}"
phase: "1 — Research"
based_on: "CONSTITUTION.md (version X.Y.Z)"
```

| Section | Required | Content |
|---------|----------|---------|
| Project Context | Yes | From CONSTITUTION.md |
| Existing Codebase | Brownfield only | From sdd_scan_codebase |
| External Input Summary | If imported | From sdd_import_* |
| Discovery Answers | Yes | Developer answers to 7 questions |
| Technical Research | Yes | Questions + findings |
| Ecosystem Recommendations | Yes | From sdd_check_ecosystem |
| Open Questions | Yes | Unresolved items for clarify phase |

---

### DESIGN.md (Phase 4 — Design)

```yaml
title: "Design — {Feature Name}"
phase: "4 — Design"
based_on: "SPECIFICATION.md (version X.Y.Z)"
```

12-section template. Required sections:

| # | Section | Mermaid Diagram |
|---|---------|-----------------|
| 1 | System Context (C4 L1) | Yes — context diagram |
| 2 | Container Architecture (C4 L2) | Yes — container diagram |
| 3 | Component Design (C4 L3) | Yes — component diagram |
| 4 | Code-Level Design (C4 L4) | Optional |
| 5 | System Diagrams | Yes — sequence + flow |
| 6 | Data Model | Yes — ERD |
| 7 | API Contracts | Endpoint table |
| 8 | Infrastructure | Deployment diagram |
| 9 | Security Architecture | Auth flow diagram |
| 10 | ADRs | Min 2 decisions |
| 11 | Error Handling | Error code table |
| 12 | Cross-Cutting Concerns | Logging, monitoring |

---

### TASKS.md (Phase 5 — Tasks)

```yaml
title: "Tasks — {Feature Name}"
phase: "5 — Tasks"
based_on: "DESIGN.md (version X.Y.Z)"
```

| Column | Required | Content |
|--------|----------|---------|
| ID | Yes | `T-{NNN}` |
| Task | Yes | What to do |
| [P] | Yes if parallel | Parallel marker |
| Effort | Yes | S/M/L/XL |
| Depends On | Yes | Task IDs |
| Traces To | Yes | `REQ-{DOMAIN}-{NN}` |

---

### ANALYSIS.md (Phase 8 — Review)

```yaml
title: "Analysis — {Feature Name}"
phase: "8 — Review"
based_on: "All spec artifacts"
```

Must include: Traceability Matrix, Coverage Report, Gap Analysis, Risk Assessment, Gate Decision (APPROVE/REVISE/BLOCK).

---

### CHECKLIST.md (Phase 6 — Implement)

```yaml
title: "Quality Checklist — {Feature Name}"
phase: "6 — Implement"
based_on: "SPECIFICATION.md + DESIGN.md"
```

Checklist items per domain: security, testing, performance, accessibility, deployment, documentation.

---

### VERIFICATION.md (Phase 7 — Verify)

```yaml
title: "Verification Report — {Feature Name}"
phase: "7 — Verify"
based_on: "SPECIFICATION.md + test results"
```

Must include: Test Results Summary, Requirement Traceability table, Failure Details, Phantom Completion Check, Spec-Code Drift, Gate Decision.

---

### CROSS_ANALYSIS.md (Phase 8 — Review)

```yaml
title: "Cross Analysis — {Feature Name}"
phase: "8 — Review"
based_on: "SPECIFICATION.md + DESIGN.md + TASKS.md"
```

Spec-design-tasks alignment score. Consistency matrix.

---

### COMPLIANCE.md (Phase 8 — Review)

```yaml
title: "Compliance Report — {Feature Name}"
phase: "8 — Review"
based_on: "SPECIFICATION.md + DESIGN.md"
```

Per-framework section: HIPAA, SOC2, GDPR, PCI-DSS, ISO27001. Each control: PASS/FAIL/N/A with evidence.

---

## 4. Formatting Rules

### Text
- Active voice: "The system processes..." not "The data is processed..."
- `must` not `should` in requirements
- Bold for key terms on first use: **Model Context Protocol (MCP)**
- Inline code for technical terms: `sdd_init`, `.sdd-state.json`

### Tables
- Always include header row
- Use for structured data with 3+ columns
- Cell content < 50 characters

### Code Blocks
- Always specify language: ` ```typescript `
- Max 30 lines per block
- Brief description before each block

### Mermaid Diagrams
- Required in DESIGN.md (minimum 4 diagrams)
- Recommended in ANALYSIS.md (traceability flow)
- Use `graph`, `sequenceDiagram`, `erDiagram`, `classDiagram`, `stateDiagram`

### REQ-ID References
- Format: `REQ-{DOMAIN}-{NN}` where DOMAIN is uppercase, NN is zero-padded
- Must appear in: SPECIFICATION.md (defined), TASKS.md (traced), test files (commented)
- Cross-document links: `[REQ-AUTH-01](./SPECIFICATION.md#req-auth-01)`

---

## 5. Anti-Patterns

| Anti-Pattern | Why It's Wrong | Fix |
|-------------|---------------|-----|
| Missing frontmatter | Breaks tooling, no version tracking | Always include all 9 fields |
| No Change Log | No history of what changed | Add table after frontmatter |
| Unnumbered headings | TOC breaks, hard to reference | Number all H2 and H3 |
| Requirements using "should" | Not testable, not enforceable | Replace with "must" |
| No `based_on` field | Traceability chain broken | Always reference upstream artifact |
| Mermaid without description | Diagram without context is noise | Add 1-2 sentence intro before each diagram |
| REQ-IDs in lowercase | Convention violation, grep breaks | Always `REQ-UPPERCASE-NN` |
| Missing References section | No citation trail | Add at end of every document |
