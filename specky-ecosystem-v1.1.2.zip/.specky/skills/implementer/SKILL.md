---
name: implementer
description: "Implementation orchestrator skill. Generates ordered implementation plans, quality checklists, test stubs with REQ-ID traceability, IaC scaffolding, and dev environment configs. Use when: transitioning from spec to code, generating test stubs, setting up infrastructure, configuring dev environments, creating implementation plans. DO NOT USE for writing production code or modifying upstream spec artifacts."
---

# Implementer Skill

---
**Model:** `claude-sonnet-4-6`
**Chat mode:** Agent
**Extended thinking:** No
**Rationale:** Implementation is iterative with executable feedback. Extended thinking on implementation phases costs +43% and degrades quality -30% (arXiv:2502.08235). Use fast models with no reasoning overhead.

---

## 0. Model Routing

| Task | Model | Mode | Extended Thinking |
|------|-------|------|-------------------|
| Generate implementation plan from TASKS.md | `claude-sonnet-4-6` | Agent | No |
| Generate quality checklists | `claude-sonnet-4-6` | Agent | No |
| Generate test stubs | `claude-sonnet-4-6` | Agent | No |
| Generate PBT from EARS invariants | `claude-sonnet-4-6` | Agent | No |
| Generate IaC (Terraform/Bicep) | `claude-sonnet-4-6` | Agent | No |
| Complex architecture decision during impl | `claude-opus-4-6` | Ask | Yes |

**Escalation rule:** If a task has >10 files or >3 service boundaries, escalate to Opus for that specific subtask. Return to Sonnet immediately after.

---

## 1. Prerequisites Check

Before generating anything, validate:

| Check | Required File | Tool | Failure Action |
|-------|--------------|------|----------------|
| Phase 5 complete | `.sdd-state.json` | `sdd_get_status` | Tell developer to complete Phase 5 first |
| TASKS.md exists | `.specs/NNN/TASKS.md` | File read | Cannot proceed without tasks |
| DESIGN.md exists | `.specs/NNN/DESIGN.md` | File read | Cannot proceed without design |
| Every task has REQ-* | TASKS.md content | Grep | Flag untraceable tasks |

---

## 2. Implementation Plan Generation

### What `sdd_implement` produces

The tool reads TASKS.md and generates:

| Section | Content |
|---------|---------|
| Phase groups | Foundation → Core → Integration → Polish |
| Task sequence | Dependency-resolved order within each phase |
| Parallel markers | [P] for tasks that can run simultaneously |
| Checkpoints | Verification gates between phases |
| Complexity | S (1-3 files) / M (4-8 files) / L (9-15 files) / XL (16+, split recommended) |

### Phase Group Rules

| Phase | Contains | Must Complete Before |
|-------|----------|---------------------|
| Foundation | Data models, schemas, base config, auth setup | Everything |
| Core | Primary business logic, main API endpoints | Integration |
| Integration | External service connections, webhooks, notifications | Polish |
| Polish | Error handling improvements, logging, monitoring, docs | Release |

### XL Task Splitting

If any task is classified XL (>15 files), split it:
1. Extract the data layer (models, repositories) as a separate S/M task
2. Extract the API layer (controllers, routes) as a separate M task
3. Keep business logic as the core M/L task
4. Each subtask inherits the parent's REQ-* traceability

---

## 3. Quality Checklist Domains

### Mandatory (every project)

#### Security Checklist (`sdd_checklist domain: "security"`)
- Input validation on all endpoints (server-side, never trust client)
- Authentication verified on protected routes
- Authorization checked per resource (not just per route)
- Secrets in environment variables, never in code
- SQL injection prevention (parameterized queries or ORM)
- XSS prevention (output encoding, CSP headers)
- CSRF protection on state-changing endpoints
- Rate limiting on auth endpoints
- Dependency vulnerability scan (npm audit / pip audit)
- Error messages reveal no internal details

#### Testing Checklist (`sdd_checklist domain: "testing"`)
- Unit tests for all business logic methods
- Integration tests for API endpoints with test database
- Every P0 requirement has at least one test
- Test stubs include REQ-XXX traceability comments
- Edge cases: empty input, max length, concurrent access
- Error paths tested (not just happy path)
- Test data is deterministic (seeded, not random)

### Conditional (based on NFRD)

| NFR Present | Checklist Domain | Key Items |
|-------------|-----------------|-----------|
| NFR-01 Performance | `performance` | Load test scenarios, p95 thresholds, database indexing, N+1 query detection |
| NFR-03 Availability | `deployment` | Health check endpoint, graceful shutdown, zero-downtime deploy, rollback procedure |
| NFR-06 Observability | `deployment` | Structured logging, correlation IDs, metrics endpoints, alert thresholds |
| NFR-07 Accessibility | `accessibility` | WCAG level, keyboard navigation, screen reader, contrast ratios, focus management |
| NFR-08 Localization | `documentation` | i18n key extraction, RTL support check, date/number format |

---

## 4. Test Framework Selection

### Auto-detection priority

1. NFRD Technology Stack Constraints → explicit framework
2. `package.json` devDependencies → vitest/jest/playwright
3. `requirements.txt` / `pyproject.toml` → pytest
4. `pom.xml` / `build.gradle` → junit
5. `*.csproj` → xunit
6. Default: vitest (TypeScript) or pytest (Python)

### Test Stub Requirements

Every generated test stub MUST include:

```
// REQ-{DOMAIN}-{NUMBER} — {requirement title}
```

Example:
```typescript
describe("Authentication", () => {
  it("must return JWT on valid credentials", () => {
    // REQ-AUTH-01 — User authentication with JWT
    // TODO: implement test
    expect(true).toBe(true);
  });
});
```

### When to generate PBT

Call `sdd_generate_pbt` when EARS requirements contain:

| EARS Pattern | PBT Property Type |
|-------------|-------------------|
| Ubiquitous ("The system shall always...") | Invariant property |
| State-driven ("While X, the system shall...") | State machine property |
| Event-driven ("When X, then Y") | Round-trip property (do/undo) |
| Unwanted ("If X fails, then...") | Negative property |
| Any idempotent operation | Idempotence property |

---

## 5. Infrastructure Generation Decision Tree

```
Has deployment architecture in DESIGN.md?
├── No → Skip infrastructure. This is a library/CLI/MCP server.
└── Yes
    ├── Multi-cloud? → sdd_generate_iac(provider: "terraform")
    ├── Azure-only? → sdd_generate_iac(provider: "bicep")
    ├── Containerized?
    │   ├── Yes → sdd_generate_dockerfile
    │   └── No → Skip Docker
    ├── Team > 1?
    │   ├── Yes → sdd_generate_devcontainer + sdd_setup_local_env
    │   └── No → sdd_setup_local_env only
    └── GitHub Codespaces in use?
        ├── Yes → sdd_setup_codespaces
        └── No → Skip
```

---

## 6. Spec-Sync During Implementation

The `spec-sync.sh` hook runs automatically on every code change during Phase 6. It detects drift between SPECIFICATION.md requirements and the implementation.

**When spec-sync reports drift:**
1. Read the SYNC_REPORT.md
2. Classify drift: intentional (scope change) vs accidental (missed requirement)
3. If intentional → suggest `sdd_amend` to update CONSTITUTION.md
4. If accidental → flag the task and requirement ID for the developer

**Never suppress spec-sync warnings.** Drift detection is the primary quality signal during implementation.

---

## 7. Implementation Handoff Template

Deliver this after all scaffolding is generated:

```markdown
## Implementation Handoff

**Feature:** {feature_number} — {feature_name}
**Pipeline phase:** 6 — Implement
**Date:** {YYYY-MM-DD}

### Implementation Plan
- Tasks: {total} across {phase_count} phases
- Parallel groups: {count}
- Estimated effort: {S|M|L|XL}
- Critical path: {task IDs on critical path}

### Test Scaffolding
- Framework: {framework}
- Unit test stubs: {count} (all with REQ-* traceability)
- PBT tests: {count or "N/A"}
- E2E tests: {count or "N/A"}

### Quality Checklists
- Security: {item_count} items
- Testing: {item_count} items
- {additional domains}: {item_count} items each

### Infrastructure
- IaC: {Terraform|Bicep|N/A}
- Docker: {Dockerfile + compose|N/A}
- DevContainer: {Yes|N/A}
- Codespaces: {Yes|N/A}

### Model Routing for Coding
- Implementation: `claude-sonnet-4-6`, thinking: false
- Complex architecture subtasks: escalate to `claude-opus-4-6`

### Active Hooks
- `spec-sync.sh` — monitoring drift on every code change
- `auto-checkpoint.sh` — snapshotting on spec artifact writes

### Next Step
When implementation is complete and tests are passing, hand off to `test-verifier` agent.
Run: `/sdd:test {feature_number}` or `@test-verifier verify feature {feature_number}`
```

---

## 8. Anti-Patterns

| Anti-Pattern | Why It's Wrong | Correct Approach |
|-------------|---------------|------------------|
| Writing production code in the agent | Implementer scaffolds, developer implements | Generate plan + stubs, hand off |
| Using Opus for test stub generation | Test stubs are template-based, not reasoning | Sonnet with thinking: false |
| Generating IaC without reading DESIGN.md | IaC must match architecture decisions | Read DESIGN.md components first |
| Skipping security checklist for internal tools | Internal tools are attack vectors too | Always generate security checklist |
| Generating tests without REQ-ID comments | Untraceable tests are phantom coverage | Every test stub must reference REQ-XXX |
| Ignoring spec-sync drift warnings | Drift compounds — small drift becomes large divergence | Address every drift report immediately |
