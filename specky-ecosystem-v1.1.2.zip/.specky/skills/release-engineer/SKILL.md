---
name: release-engineer
description: "Release process skill. Covers blocking gate validation (security-scan, release-gate), documentation generation patterns, PR templates, changelog format, work item export, and semantic versioning. Use when: preparing releases, creating PRs, generating docs, running pre-merge checks. DO NOT USE for writing code, tests, or specifications."
---

# Release Engineer Skill

---
**Model:** `claude-haiku-4-5`
**Chat mode:** Agent
**Extended thinking:** No
**Rationale:** Release tasks are deterministic. Doc generation, PR formatting, changelog writing — all template-based. Haiku at 0.33x is the correct cost tier.

---

## 0. Model Routing

| Task | Model | Mode | Extended Thinking |
|------|-------|------|-------------------|
| Generate docs + create PR + export items | `claude-haiku-4-5` | Agent | No |
| Diagnose blocking gate failure | `claude-sonnet-4-6` | Ask | No |
| Complex release decision (breaking change) | `claude-opus-4-6` | Ask | Yes |

---

## 1. Blocking Gates

### security-scan.sh

Runs before any release action. Exit codes:
- `0` → PASS, proceed
- `2` → BLOCKED, must fix before release

What it checks:
| Check | Tool | Common Fix |
|-------|------|-----------|
| OWASP Top 10 | npm audit / pip audit | Update vulnerable dependency |
| Hardcoded secrets | grep for patterns (API keys, tokens, passwords) | Move to env vars / secret manager |
| Sensitive file exposure | Check .gitignore for credentials, keys, configs | Add to .gitignore, rotate exposed secrets |

**When security-scan fails, always:**
1. Quote the exact error from the scan
2. Explain what the vulnerability is in plain language
3. Give the specific fix command (e.g., `npm audit fix`, `git rm --cached .env`)
4. Warn about rotation if secrets were exposed in git history

### release-gate.sh

Runs before PR creation. Exit codes:
- `0` → PASS, proceed
- `2` → BLOCKED, must complete verification

What it checks:
| Check | Required | Fix |
|-------|----------|-----|
| VERIFICATION.md exists | Yes | Run `/sdd:test` first |
| CHECKLIST.md exists | Yes | Run `/sdd:implement` first |
| Test pass rate ≥90% | Yes | Fix failing tests, re-run `/sdd:test` |

---

## 2. Documentation Types

### sdd_generate_all_docs (recommended — parallel generation)

Generates all 5 types simultaneously. Faster than calling each individually.

| Type | File | Content |
|------|------|---------|
| Full docs | `docs/README.md` | Complete project documentation with setup, usage, architecture |
| API docs | `docs/API.md` | Endpoint reference, request/response examples, error codes |
| Runbook | `docs/RUNBOOK.md` | Operational procedures, monitoring, alerting, incident playbook |
| Onboarding | `docs/ONBOARDING.md` | Getting started, dev setup, architecture overview, first task guide |
| Journey | `docs/JOURNEY.md` | User journey map derived from specification user flows |

### Doc type relevance by project type

| Project Type | Full | API | Runbook | Onboarding | Journey |
|-------------|------|-----|---------|------------|---------|
| API service | ✅ | ✅ | ✅ | ✅ | ✅ |
| Web app | ✅ | ✅ | ✅ | ✅ | ✅ |
| Library/SDK | ✅ | ✅ | ❌ | ✅ | ❌ |
| CLI tool | ✅ | ❌ | ❌ | ✅ | ❌ |
| MCP server | ✅ | ✅ | ✅ | ✅ | ❌ |
| Internal tool | ✅ | ❌ | ✅ | ✅ | ✅ |

---

## 3. PR Template

### PR title convention

```
feat(NNN): {feature name}
```

Where NNN is the feature number from `.specs/NNN-feature-name/`.

### PR body structure

```markdown
## Summary

{One paragraph from SPECIFICATION.md Section 1.1 — what this feature does}

## Specification Coverage

| Metric | Value |
|--------|-------|
| Total requirements | {n} |
| P0 requirements | {n} |
| Test pass rate | {XX.X}% |
| Spec-code drift | {X}% |
| Compliance | {frameworks checked or N/A} |

## Key Design Decisions

{Top 3 ADRs from DESIGN.md, one sentence each}

## How to Test

{Primary acceptance test scenario from P0 requirements}

## Checklist

- [ ] All P0 requirements have passing tests
- [ ] Security scan passes (no secrets, no OWASP findings)
- [ ] Documentation generated and reviewed
- [ ] VERIFICATION.md confirms ≥90% pass rate
- [ ] No phantom completions in TASKS.md
```

---

## 4. Work Item Export

### Supported platforms

| Platform | Tool Payload | Required Fields |
|----------|-------------|----------------|
| GitHub Issues | `sdd_export_work_items(platform: "github")` | title, body, labels, milestone |
| Azure Boards | `sdd_export_work_items(platform: "azure_boards")` | title, description, work_item_type, area_path |
| Jira | `sdd_export_work_items(platform: "jira")` | summary, description, issue_type, project_key |

### What gets exported

- Each task from TASKS.md becomes a work item
- Status is set based on VERIFICATION.md:
  - All tests passing → "Done" / "Closed"
  - Some tests failing → "In Progress"
  - No tests → "To Do"
- Labels include: feature number, priority, domain

---

## 5. Changelog Format

Based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/):

```markdown
## [{version}] - {YYYY-MM-DD}

### Added
- {New features from P0/P1 requirements}

### Changed
- {Modified behaviors}

### Fixed
- {Bug fixes from sdd_write_bugfix}

### Security
- {Security improvements from compliance check}
```

### Version bump rules (Semantic Versioning)

| Change Type | Bump | Signal |
|------------|------|--------|
| New P0 feature with new API endpoints | MINOR (0.X.0) | New capability, backward compatible |
| Breaking API change | MAJOR (X.0.0) | Existing consumers must update |
| Bug fixes only | PATCH (0.0.X) | No new features |
| Security patches | PATCH (0.0.X) | Urgent, deploy immediately |

---

## 6. Release Summary Template

```markdown
## Release Summary

**Feature:** {NNN} — {feature_name}
**Version:** {semantic version}
**Date:** {YYYY-MM-DD}
**Pipeline:** All 10 phases completed ✅

### Gates
| Gate | Status |
|------|--------|
| security-scan.sh | ✅ PASS |
| release-gate.sh | ✅ PASS |

### Quality Metrics
| Metric | Value |
|--------|-------|
| Requirements | {n} total ({P0}:{P1}:{P2}:{P3}) |
| Test pass rate | {XX.X}% |
| Spec-code drift | {X}% |
| Phantom completions | 0 |
| Cognitive debt score | {healthy|caution|high_risk} |

### Artifacts Delivered
- PR: feat({NNN}): {feature_name}
- Documentation: {list of generated doc types}
- Work items: {n} items on {platform} (or N/A)

### Pipeline Duration
- Phase 0-5 (Spec to Tasks): {time}
- Phase 6 (Implementation): {time}
- Phase 7-8 (Verify + Review): {time}
- Phase 9 (Release): {time}
- Total: {time}
```

---

## 7. Anti-Patterns

| Anti-Pattern | Why It's Wrong | Correct Approach |
|-------------|---------------|------------------|
| Creating PR without running blocking hooks | Hooks catch secrets and missing verification | Always verify hooks before PR |
| Skipping documentation for "small" features | Every feature needs at minimum full docs | Generate docs for every release |
| Manual changelog writing | Inconsistent format, missed items | Use template, derive from spec artifacts |
| Exporting work items without confirming platform | Wrong platform = wasted effort | Ask developer which platform |
| Using Opus for doc generation | Doc generation is template-based | Haiku at 0.33x cost |
| Shipping without VERIFICATION.md | No evidence of testing | release-gate.sh blocks this, but catch early |
