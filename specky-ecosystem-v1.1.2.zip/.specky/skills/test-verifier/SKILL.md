---
name: test-verifier
description: "Test verification and traceability skill. Methodology for parsing test results, mapping to requirements via REQ-ID, detecting phantom completions, measuring spec-code drift, and producing verification reports. Use when: verifying tests, checking coverage, detecting phantoms, validating implementation completeness. DO NOT USE for writing tests or code — that is the implementer's job."
---

# Test Verifier Skill

---
**Model:** `claude-sonnet-4-6`
**Chat mode:** Agent
**Extended thinking:** No
**Rationale:** Test verification is comparison and pattern-matching. The programmatic tools (TestResultParser, TestTraceabilityMapper) handle the complexity. The agent role is orchestration and reporting.

---

## 0. Model Routing

| Task | Model | Mode | Extended Thinking |
|------|-------|------|-------------------|
| Parse results + build coverage report | `claude-sonnet-4-6` | Agent | No |
| Diagnose complex test failures | `claude-opus-4-6` | Ask | Yes |
| Quick pass/fail status check | `claude-haiku-4-5` | Ask | No |

---

## 1. Test Result Formats

Specky's `TestResultParser` auto-detects these formats:

| Format | Framework | Detection Signal |
|--------|-----------|-----------------|
| Vitest JSON | vitest | `"testResults"` key with `"assertionResults"` |
| pytest JSON | pytest (with `--json-report`) | `"tests"` key with `"outcome"` field |
| JUnit XML | JUnit, xUnit, NUnit | `<testsuites>` or `<testsuite>` root element |

### Running tests to produce parseable output

```bash
# Vitest
npx vitest run --reporter=json --outputFile=test-results.json

# pytest
pytest --json-report --json-report-file=test-results.json

# JUnit (Maven)
mvn test  # produces target/surefire-reports/*.xml

# xUnit (.NET)
dotnet test --logger "junit;LogFilePath=test-results.xml"
```

---

## 2. REQ-ID Traceability Convention

### How tests map to requirements

The `TestTraceabilityMapper` scans test files for comments matching:

```
// REQ-{DOMAIN}-{NUMBER}
# REQ-{DOMAIN}-{NUMBER}
/* REQ-{DOMAIN}-{NUMBER} */
```

Examples:
```typescript
it("must return JWT on valid login", () => {
  // REQ-AUTH-01 — User authentication
  expect(response.status).toBe(200);
});
```

```python
def test_valid_login_returns_jwt():
    # REQ-AUTH-01 — User authentication
    assert response.status_code == 200
```

### Traceability report structure

For each requirement, the mapper produces:

| Field | Content |
|-------|---------|
| `requirement_id` | REQ-AUTH-01 |
| `requirement_title` | User authentication with JWT |
| `priority` | P0 |
| `tests_mapped` | 3 |
| `tests_passing` | 2 |
| `tests_failing` | 1 |
| `coverage_status` | PARTIAL |
| `failure_details` | Test name, error message, file:line |
| `suggested_fix_prompt` | "The test expects status 200 but got 401. Check that the auth middleware accepts the test JWT token." |

---

## 3. Phantom Completion Detection

### What is a phantom completion?

A task in TASKS.md marked as "done" or "complete" with no corresponding code evidence. This is the most dangerous quality problem because it creates an illusion of progress.

### Detection method

`sdd_verify_tasks` compares:
1. Task file references in TASKS.md (e.g., "Implement in `src/services/auth.ts`")
2. Actual files in the project tree
3. File modification timestamps vs task completion timestamps

### Classification

| Finding | Classification | Severity |
|---------|---------------|----------|
| Task done + file exists + tests pass | ✅ Genuine completion | None |
| Task done + file exists + tests fail | ⚠️ Incomplete implementation | HIGH |
| Task done + file missing | 🚫 Phantom completion | CRITICAL |
| File exists + no task | ⚠️ Unplanned work (scope creep) | MEDIUM |
| Task not started + file exists | ℹ️ Pre-existing code | LOW |

### Phantom completion response

When phantoms are detected:
1. List each phantom with its task ID and expected file
2. Recommend the developer either implement the task or mark it as "not started"
3. Do NOT allow phase advancement with phantom completions — this is a gate blocker

---

## 4. Spec-Code Drift Assessment

### What `sdd_check_sync` measures

| Metric | Definition | Threshold |
|--------|-----------|-----------|
| Missing implementations | Requirements with no matching code | 0 for P0, ≤2 for P1 |
| Undocumented behavior | Code with no matching requirement | Flag for review |
| Spec drift | Requirements modified after design was written | ≤20% of total requirements |
| Stale acceptance criteria | AC that no longer matches the code behavior | 0 for P0 |

### Drift severity scale

| Drift % | Severity | Action |
|---------|----------|--------|
| 0-10% | Normal | Proceed to review |
| 11-20% | Caution | Recommend spec update before review |
| 21-40% | Warning | Run `sdd_amend` before review — spec and code have diverged |
| >40% | Critical | Stop. Re-run sdd_clarify and sdd_write_spec. Implementation has gone off-spec. |

---

## 5. Verification Gate Criteria

All four must pass for the gate to open:

| Criterion | Threshold | Measurement |
|-----------|-----------|-------------|
| Test pass rate | ≥90% | `(passing_tests / total_tests) × 100` |
| P0 coverage | 100% | Every P0 requirement has ≥1 passing test |
| Phantom completions | 0 | No tasks marked done without code |
| Spec-code drift | ≤20% | Drift percentage from sdd_check_sync |

### Partial pass handling

If 3 of 4 criteria pass:
- Missing only P1+ coverage → CONDITIONAL PASS, list uncovered P1+ requirements
- Missing only drift ≤20% → FAIL, must run sdd_amend first
- Missing only pass rate → FAIL, must fix failing tests
- Missing only phantom check → FAIL, must resolve phantoms

---

## 6. VERIFICATION.md Structure

The artifact produced by `sdd_verify_tests`:

```markdown
---
title: "Verification Report — {Feature Name}"
feature_id: "{NNN-feature-name}"
version: 1.0.0
date: "{YYYY-MM-DD}"
test_framework: "{framework}"
pass_rate: "{XX.X}%"
gate_decision: "{PASS|FAIL}"
---

# Verification Report — {Feature Name}

## Test Results Summary
| Metric | Value |
|--------|-------|
| Total tests | {n} |
| Passing | {n} |
| Failing | {n} |
| Skipped | {n} |
| Pass rate | {XX.X}% |

## Requirement Traceability
| REQ-ID | Priority | Tests | Passing | Status |
|--------|----------|-------|---------|--------|
| REQ-AUTH-01 | P0 | 3 | 3 | ✅ COVERED |
| REQ-AUTH-02 | P0 | 2 | 1 | ⚠️ PARTIAL |

## Failure Details
### REQ-AUTH-02 — Session expiration
- **Test:** "must redirect on expired session"
- **Error:** Expected redirect to /login, got 500
- **File:** src/tests/auth.test.ts:45
- **Suggested fix:** Check session middleware error handling for expired tokens

## Phantom Completion Check
{Results from sdd_verify_tasks}

## Spec-Code Drift
{Results from sdd_check_sync}

## Gate Decision
{PASS/FAIL with specific criteria results}
```

---

## 7. TDD Interactive Loop (arXiv:2404.10100)

When the verification gate fails, the recommended recovery loop is:

```
FAIL → developer reads failure details
     → developer reads suggested_fix_prompt
     → developer fixes code (not spec)
     → developer re-runs tests
     → re-run sdd_verify_tests
     → check if gate passes
     → if still FAIL, repeat
     → if PASS, proceed to Review
```

Key insight from arXiv:2404.10100: the TDD interactive loop improves pass@1 by +20%. The `suggested_fix_prompt` field in failure details is specifically designed to feed this loop — it gives the developer (or coding agent) a targeted prompt for the fix.

---

## 8. Anti-Patterns

| Anti-Pattern | Why It's Wrong | Correct Approach |
|-------------|---------------|------------------|
| Approving with <90% pass rate | release-gate.sh will block anyway — catch early | Fix failing tests before advancing |
| Ignoring unmapped tests | Tests without REQ-ID are invisible to traceability | Add `// REQ-XXX` comments to every test |
| Modifying spec to match failing code | Spec is the source of truth, not code | Fix code to match spec, or run sdd_amend for legitimate scope changes |
| Skipping phantom completion check | Test coverage alone misses "done" tasks with no code | Always run sdd_verify_tasks alongside sdd_verify_tests |
| Running verification without latest test results | Stale results give false confidence | Re-run tests immediately before verification |
| Using Opus for verification | Verification is comparison, not reasoning | Sonnet is sufficient and 3x cheaper |
