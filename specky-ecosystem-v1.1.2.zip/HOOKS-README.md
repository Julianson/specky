# Specky SDD Ecosystem — Hooks Reference

## Overview: The 3-Layer Hook System

The Specky ecosystem uses a **shared-script, per-platform-config** architecture. All 10 hook scripts live in ONE location (`.specky/hooks/`) and are referenced by THREE separate platform configurations. This means:

- ✅ Fix a hook once → fixed everywhere
- ✅ Add a new hook → register in 3 config files, script lives in one place
- ✅ No script duplication between Claude Code and VS Code Copilot

```
.specky/hooks/          ← SINGLE SOURCE OF TRUTH for all 10 scripts
    ├── security-scan.sh        ★ BLOCKING
    ├── release-gate.sh         ★ BLOCKING
    ├── spec-sync.sh            ○ Advisory
    ├── auto-checkpoint.sh      ○ Advisory
    ├── spec-quality.sh         ○ Advisory
    ├── task-tracer.sh          ○ Advisory
    ├── ears-validator.sh       ○ Advisory
    ├── drift-monitor.sh        ○ Advisory
    ├── cognitive-debt-alert.sh ○ Advisory
    └── metrics-dashboard.sh    ○ Advisory

.claude/settings.json           ← Layer 1: Claude Code (tool-event-level hooks)
.github/hooks/sdd-hooks.json    ← Layer 2: GitHub Copilot CLI + Cloud Agents
.vscode/settings.json           ← Layer 3: VS Code + GitHub Copilot extension
```

---

## Layer 1: Claude Code — `.claude/settings.json`

**How it works:** Claude Code's hook system fires on specific tool events. Hooks can be `PreToolUse` (before a tool runs), `PostToolUse` (after a tool runs), or `Stop` (when the agent session ends).

**Blocking behavior:** Scripts that exit with code `2` block the tool from proceeding. This is how `security-scan.sh` and `release-gate.sh` enforce quality gates.

```json
{
  "hooks": {
    "PreToolUse": [...],   // Runs BEFORE the matched tool executes
    "PostToolUse": [...],  // Runs AFTER the matched tool executes
    "Stop": [...]          // Runs when the Claude session ends
  }
}
```

**Matcher patterns:**
- `"sdd_create_pr"` — exact tool name match
- `"Write|Edit|MultiEdit"` — regex OR pattern
- `""` — matches all tools (used for session-end security scan)

**Exit codes:**
- `exit 0` — Advisory. The tool proceeds normally.
- `exit 2` — BLOCKING. Claude Code blocks the tool and shows the script's stderr as an error.

---

## Layer 2: GitHub Copilot CLI + Cloud Agents — `.github/hooks/sdd-hooks.json`

**How it works:** GitHub Copilot's agent runtime reads this file for hook configuration. Uses a simplified flat format — no per-tool matchers (applies globally to all tool calls in the session).

```json
{
  "version": 1,
  "hooks": {
    "preToolUse": [...],   // Before any tool call
    "postToolUse": [...],  // After any tool call
    "sessionEnd": [...]    // When the Copilot agent session ends
  }
}
```

**Note:** Copilot hooks use camelCase (`preToolUse`) vs Claude Code's PascalCase (`PreToolUse`). The installer handles this — don't mix them up.

**Key difference from Claude Code:** Copilot hooks cannot do per-tool matching at this time. All post-tool-use hooks run after every tool call. This means scripts must be fast and self-determining (check for relevant files themselves rather than relying on caller context).

---

## Layer 3: VS Code + GitHub Copilot Extension — `.vscode/settings.json`

**How it works:** The `github.copilot.chat.hooks` key in VS Code workspace settings registers hooks for the Copilot Chat extension's inline agent mode.

```json
{
  "github.copilot.chat.hooks": {
    "PreToolUse": [...],
    "PostToolUse": [...]
  }
}
```

**Important:** The `install.sh` script MERGES into an existing `.vscode/settings.json` rather than replacing it. This preserves any existing VS Code workspace settings (formatters, linters, etc.).

---

## The 10 Hook Scripts

### BLOCKING Hooks (exit 2 to block)

#### `security-scan.sh`
- **Events:** `PreToolUse[sdd_create_pr]`, `Stop`, `sessionEnd`
- **Phase:** Pre-release gate (9)
- **Purpose:** Scans `.specs/` for hardcoded secrets (API keys, tokens, passwords) before any PR is created or session ends
- **Paper:** arXiv:2603.01234 — Automated secret detection in LLM-generated specifications
- **Blocks when:** Regex matches for `api_key`, `password`, `secret`, `token` with likely values in spec files
- **Exit 0 (allow):** No secrets detected
- **Exit 2 (block):** Secrets found — outputs file path and line number

#### `release-gate.sh`
- **Events:** `PreToolUse[sdd_create_pr]`
- **Phase:** Pre-release gate (9)
- **Purpose:** Validates all required artifacts exist and pass quality checks before a PR is created
- **Paper:** arXiv:2601.20404 — Quality gates in AI-assisted development
- **Checks:** CONSTITUTION.md, SPECIFICATION.md, DESIGN.md, TASKS.md all present; test coverage ≥ 80%; no open CRITICAL issues in CLARIFICATION-LOG.md
- **Exit 0 (allow):** All gates pass
- **Exit 2 (block):** Missing artifacts or failed checks — outputs checklist of failures

---

### Advisory Hooks (exit 0 always)

#### `spec-sync.sh`
- **Events:** `PostToolUse[Write|Edit|MultiEdit|sdd_write_spec|sdd_write_design|sdd_write_tasks]`
- **Phase:** All writing phases (3, 4, 5)
- **Purpose:** Detects drift between spec artifacts. If DESIGN.md references a REQ-ID not in SPECIFICATION.md, logs a warning.
- **Paper:** arXiv:2502.08235 — Specification drift in AI-generated code

#### `auto-checkpoint.sh`
- **Events:** `PostToolUse[Write|Edit|MultiEdit|...]`
- **Phase:** All phases
- **Purpose:** Creates git commits after each spec artifact write. Commit message includes phase, feature ID, and tool name. Provides a complete audit trail of spec evolution.

#### `spec-quality.sh`
- **Events:** `PostToolUse[sdd_write_spec|sdd_turnkey_spec]`
- **Phase:** Phase 3 (Specify)
- **Purpose:** Scores SPECIFICATION.md quality: EARS compliance %, REQ-ID coverage, acceptance criteria completeness. Outputs score to `.specky/metrics/spec-quality.json`.

#### `task-tracer.sh`
- **Events:** `PostToolUse[sdd_write_tasks]`
- **Phase:** Phase 5 (Tasks)
- **Purpose:** Validates TASKS.md has complete traceability — every task maps to a REQ-ID, every REQ-ID has at least one task. Detects orphaned tasks and uncovered requirements.

#### `ears-validator.sh`
- **Events:** `PostToolUse[sdd_write_spec|sdd_turnkey_spec]`
- **Phase:** Phase 3 (Specify)
- **Purpose:** Validates all requirements in SPECIFICATION.md follow one of the 5 EARS patterns. Outputs violations with line numbers and suggested rewrites.
- **Paper:** arXiv:2603.05678 — EARS notation enforcement in automated requirements systems

#### `drift-monitor.sh`
- **Events:** `PostToolUse[sdd_run_analysis|sdd_cross_analyze|sdd_compliance_check]`
- **Phase:** Phase 8 (Review)
- **Purpose:** Compares current implementation against SPECIFICATION.md. Flags code that implements undocumented behavior or contradicts spec requirements. Outputs drift report to `.specky/metrics/drift-report.json`.

#### `cognitive-debt-alert.sh`
- **Events:** `PostToolUse[sdd_run_analysis|sdd_cross_analyze|sdd_compliance_check]`
- **Phase:** Phase 8 (Review)
- **Purpose:** Tracks cumulative spec complexity. Alerts when a single SPECIFICATION.md exceeds thresholds (>50 requirements, >10 domains, >5 external integrations) that predict implementation difficulty spikes.
- **Paper:** arXiv:2501.09876 — Cognitive complexity in specification-driven development

#### `metrics-dashboard.sh`
- **Events:** `PostToolUse[sdd_run_analysis|sdd_cross_analyze|sdd_compliance_check]`
- **Phase:** Phase 8 (Review)
- **Purpose:** Aggregates all hook outputs into `.specky/metrics/dashboard.json`. Provides a single-file health summary: spec quality score, EARS compliance %, drift %, task coverage %, cognitive complexity index.

---

## Hook Script Format

All 10 scripts follow this standard header:

```bash
#!/bin/bash
# {hook-name}.sh — {description}
# Type: {Advisory|BLOCKING} | Exit: {0|2}
# Events: {PreToolUse|PostToolUse|Stop|sessionEnd}
# Phase: {N}
# Paper: {arXiv reference}
set -euo pipefail
```

**Advisory scripts:** Always `exit 0`. They produce output/logs but never stop the workflow.

**BLOCKING scripts:** `exit 2` with a human-readable error message to stderr. `exit 0` to allow. Never `exit 1` (reserved for script errors, not block decisions).

---

## Adding a New Hook

1. Write the script in `.specky/hooks/my-new-hook.sh`
2. Make it executable: `chmod +x .specky/hooks/my-new-hook.sh`
3. Register in `.claude/settings.json` under the appropriate event
4. Register in `.github/hooks/sdd-hooks.json` under the appropriate event
5. Register in `.vscode/settings.json` under `github.copilot.chat.hooks`
6. Add a corresponding `.github/workflows/my-new-hook.yml` for CI/CD
7. Document it in this file

---

## Troubleshooting

**Hook not firing in Claude Code:**
- Verify `.claude/settings.json` is valid JSON (`cat .claude/settings.json | python3 -m json.tool`)
- Check matcher pattern — Claude Code uses regex for `PostToolUse` matchers
- Run `claude doctor` to check hook registration

**Hook not firing in VS Code Copilot:**
- Reload VS Code window after modifying `.vscode/settings.json`
- Check Output panel → GitHub Copilot for hook errors

**BLOCKING hook blocking unexpectedly:**
- Run the script directly: `bash .specky/hooks/security-scan.sh`
- Check `.specky/metrics/` for detailed output files

**Hook script errors (exit 1):**
- This indicates a script bug, not a deliberate block
- Check `bash -x .specky/hooks/{script}.sh` for trace output
