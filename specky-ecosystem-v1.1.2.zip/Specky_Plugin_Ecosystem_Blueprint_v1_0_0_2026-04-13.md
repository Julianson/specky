---
title: "Specky Plugin Ecosystem Blueprint"
description: "Complete map of agents, skills, instructions, prompts, and hooks across the 10-phase SDD pipeline. Foundation for the plugin/extension system."
author: "Paula Silva"
date: "2026-04-13"
version: "1.0.0"
status: "draft"
tags: ["specky", "plugins", "ecosystem", "agents", "skills", "hooks", "SDD"]
specky_version: "3.2.0"
repo: "https://github.com/paulasilvatech/specky"
---

# Specky Plugin Ecosystem Blueprint

> The definitive map: what agents, skills, instructions, prompts, and hooks the Specky ecosystem needs — and which MCP tools each one uses.

---

## Table of Contents

1. [Design Principles](#1-design-principles)
2. [Ecosystem Architecture](#2-ecosystem-architecture)
3. [Phase-by-Phase Map](#3-phase-by-phase-map)
4. [Complete Plugin Inventory](#4-complete-plugin-inventory)
5. [Plugin Manifest Spec](#5-plugin-manifest-spec)
6. [File Tree](#6-file-tree)
7. [Handoff Contracts Between Plugins](#7-handoff-contracts-between-plugins)
8. [What Exists vs What Must Be Built](#8-what-exists-vs-what-must-be-built)
9. [Implementation Phases](#9-implementation-phases)
10. [Anti-Patterns](#10-anti-patterns)

---

## 1. Design Principles

### 1.1 One Agent Per Responsibility, Not Per Phase

An agent owns a **responsibility domain** (requirements, architecture, testing), not a pipeline phase number. Some agents span multiple phases. Some phases use multiple agents. The mapping is M:N, not 1:1.

### 1.2 Skills Are Knowledge, Not Actors

Skills contain domain knowledge (templates, checklists, validation rules). Skills never call tools directly — agents and prompts load skills and apply the knowledge through Specky MCP tools.

### 1.3 Hooks Are Zero-LLM-Cost Guardrails

Hooks run shell scripts. They enforce invariants without spending tokens. Blocking hooks gate the pipeline; advisory hooks coach without blocking.

### 1.4 Prompts Are Lightweight Entry Points

Prompts (`.claude/commands/`) are thin wrappers that load one skill and invoke one or two tools. They are the `/sdd:*` commands users type in Claude Code.

### 1.5 Instructions Are Environment Config

Instructions (CLAUDE.md, `.github/copilot-instructions.md`) set the operating context: model routing, tool inventory, conventions. They are loaded once per session, not per command.

### 1.6 Dual-Target Everything

Every agent ships as both `.github/agents/{name}.agent.md` (Copilot) AND `.claude/commands/{name}.md` (Claude Code). Single source, dual deploy.

---

## 2. Ecosystem Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                      SPECKY MCP SERVER (v3.2.0)                     │
│                        57 tools / 29 services                       │
│                    The engine. Always running.                       │
└────────────────────────────┬────────────────────────────────────────┘
                             │ MCP protocol (stdio or HTTP)
                             │
┌────────────────────────────┴────────────────────────────────────────┐
│                        PLUGIN LAYER                                 │
│                                                                     │
│  ┌─────────────┐  ┌──────────┐  ┌──────────┐  ┌─────────────────┐ │
│  │   AGENTS    │  │  SKILLS  │  │  HOOKS   │  │   REFERENCES    │ │
│  │ (actors)    │  │ (knowledge)│ │(guardrails)│ │ (loaded by skill)│ │
│  │             │  │          │  │          │  │                 │ │
│  │ Call tools  │  │ Templates│  │ Shell    │  │ EARS notation   │ │
│  │ Orchestrate │  │ Checklists│ │ scripts  │  │ Spec templates  │ │
│  │ Route models│  │ Patterns │  │ Zero LLM │  │ Design patterns │ │
│  └──────┬──────┘  └────┬─────┘  └────┬─────┘  └───────┬─────────┘ │
│         │              │             │                 │           │
│  ┌──────┴──────┐  ┌────┴─────┐  ┌────┴─────┐                     │
│  │   PROMPTS   │  │INSTRUCTIONS│ │  CONFIG  │                     │
│  │ (commands)  │  │(env setup) │ │(.specky/)│                     │
│  │ /sdd:*      │  │ CLAUDE.md  │ │config.yml│                     │
│  │ thin entry  │  │ copilot-*  │ │plugins.yml│                    │
│  └─────────────┘  └──────────┘  └──────────┘                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. Phase-by-Phase Map

### Legend

- **Agent** = the actor that orchestrates the phase (Copilot `@agent` or Claude Code command)
- **Skill** = knowledge payload the agent loads before acting
- **Primary tools** = the Specky MCP tools the agent calls
- **Supporting tools** = optional tools that enrich the phase
- **Hook** = automation that runs before/after the phase
- **Model** = recommended model from `sdd_model_routing`
- **Artifact** = file produced in `.specs/NNN-feature/`
- **Gate** = what must pass before `sdd_advance_phase` succeeds

---

### Phase 0 — Init

| Element | Value |
|---------|-------|
| **Purpose** | Create the project constitution and initialize the state machine |
| **Agent** | `requirements-engineer` (if starting from raw input) OR direct tool call |
| **Skill loaded** | `requirements-engineer` (for FRD/NFRD creation before init) |
| **Primary tools** | `sdd_init` |
| **Supporting tools** | `sdd_scan_codebase` (brownfield/modernization detection) |
| **Hook (after)** | `auto-checkpoint.sh` — snapshot initial constitution |
| **Model** | `claude-haiku-4-5` (scaffold only, no reasoning needed) |
| **Artifact** | `CONSTITUTION.md` |
| **Gate** | CONSTITUTION.md exists with valid YAML frontmatter |
| **Input** | FRD + NFRD (from requirements-engineer) OR feature name + description |
| **Output** | Initialized `.specs/NNN-feature/` directory with CONSTITUTION.md + `.sdd-state.json` |

**Workflow:**
```
[Raw input / idea / PRD / transcript]
    → requirements-engineer (skill) produces FRD + NFRD
    → sdd_init(feature_name, description, constraints from FRD/NFRD)
    → CONSTITUTION.md created
    → auto-checkpoint.sh runs
    → sdd_advance_phase → Phase 1
```

---

### Phase 1 — Research

| Element | Value |
|---------|-------|
| **Purpose** | Resolve unknowns, research technical questions, scan existing codebase |
| **Agent** | `research-analyst` (NEW) |
| **Skill loaded** | `research-analyst` (NEW — research methodology, question taxonomy) |
| **Primary tools** | `sdd_research`, `sdd_scan_codebase`, `sdd_check_ecosystem` |
| **Supporting tools** | `sdd_import_document`, `sdd_import_transcript`, `sdd_figma_to_spec` |
| **Hook (after)** | None (research is exploratory) |
| **Model** | `claude-sonnet-4-6` (information synthesis, no deep reasoning needed) |
| **Artifact** | `RESEARCH.md` |
| **Gate** | RESEARCH.md exists with at least 3 answered questions |
| **Input** | CONSTITUTION.md + any external documents/transcripts |
| **Output** | RESEARCH.md with structured findings, tech stack detection, ecosystem recommendations |

**Workflow:**
```
CONSTITUTION.md
    → sdd_scan_codebase (brownfield: detect existing stack)
    → sdd_check_ecosystem (recommend MCP servers)
    → sdd_research(questions from constitution)
    → [optional] sdd_import_document / sdd_import_transcript
    → RESEARCH.md written
    → sdd_advance_phase → Phase 2
```

---

### Phase 2 — Clarify

| Element | Value |
|---------|-------|
| **Purpose** | Disambiguate requirements, resolve CRITICAL gaps, validate EARS patterns |
| **Agent** | `spec-reviewer` (existing) — reused for disambiguation |
| **Skill loaded** | `sdd-spec-engineer` (EARS notation rules, disambiguation patterns) |
| **Primary tools** | `sdd_clarify`, `sdd_validate_ears` |
| **Supporting tools** | `sdd_turnkey_spec` (if spec exists but needs EARS conversion) |
| **Hook (after)** | `ears-validator.sh` — validate EARS pattern compliance |
| **Model** | `claude-opus-4-6` + extended thinking (high ambiguity, reasoning-intensive) |
| **Artifact** | Updated `SPECIFICATION.md` (clarifications applied) |
| **Gate** | All CRITICAL disambiguation questions resolved, EARS validation passes |
| **Input** | SPECIFICATION.md (draft from Phase 3 preview or imported) + RESEARCH.md |
| **Output** | Clarified SPECIFICATION.md with zero ambiguous requirements |

**Workflow:**
```
SPECIFICATION.md (draft)
    → sdd_clarify → returns disambiguation questions
    → Human answers questions
    → sdd_validate_ears → checks all 6 patterns
    → ears-validator.sh runs
    → sdd_advance_phase → Phase 3
```

**Note:** Phases 2 and 3 form a loop. Clarify reads spec, produces questions; Specify incorporates answers. The state machine allows backward transition 3→2 for re-clarification.

---

### Phase 3 — Specify

| Element | Value |
|---------|-------|
| **Purpose** | Write formal EARS-notation requirements with acceptance criteria |
| **Agent** | `spec-engineer` (existing) |
| **Skill loaded** | `sdd-spec-engineer` + `references/ears-notation.md` |
| **Primary tools** | `sdd_write_spec` |
| **Supporting tools** | `sdd_turnkey_spec` (fast path), `sdd_validate_ears`, `sdd_generate_user_stories` |
| **Hook (after)** | `spec-quality.sh` — req count ≥ 5, AC coverage, REQ-ID format |
| **Hook (after)** | `auto-checkpoint.sh` — snapshot spec |
| **Model** | `claude-opus-4-6` + extended thinking (specification is the highest-value reasoning phase) |
| **Artifact** | `SPECIFICATION.md` |
| **Gate** | All requirements in EARS notation, every FR has acceptance criteria, P0 count 5-15 |
| **Input** | CONSTITUTION.md + RESEARCH.md + clarification answers |
| **Output** | Complete SPECIFICATION.md with EARS requirements, priorities, acceptance signals |

**Workflow:**
```
CONSTITUTION.md + RESEARCH.md + clarifications
    → sdd_write_spec(feature_number, spec_content_from_agent)
    → spec-quality.sh validates
    → auto-checkpoint.sh snapshots
    → [optional] sdd_generate_user_stories for stakeholder review
    → sdd_advance_phase → Phase 4
```

---

### Phase 4 — Design

| Element | Value |
|---------|-------|
| **Purpose** | Create architecture, interfaces, ADRs, Mermaid diagrams |
| **Agent** | `design-architect` (existing) |
| **Skill loaded** | `sdd-spec-engineer` (design section) + `references/design-patterns.md` |
| **Primary tools** | `sdd_write_design` |
| **Supporting tools** | `sdd_generate_diagram`, `sdd_generate_all_diagrams`, `sdd_figma_diagram` |
| **Hook (after)** | `auto-checkpoint.sh` — snapshot design |
| **Model** | `claude-opus-4-6` + extended thinking (architecture requires structural reasoning) |
| **Artifact** | `DESIGN.md` |
| **Gate** | All spec requirements traced to design components, Mermaid diagrams present, ADRs for key decisions |
| **Input** | SPECIFICATION.md + CONSTITUTION.md + RESEARCH.md |
| **Output** | 12-section DESIGN.md with C4 diagrams, ERDs, sequence diagrams, API contracts |

**Workflow:**
```
SPECIFICATION.md + CONSTITUTION.md
    → sdd_write_design(feature_number, design_content_from_agent)
    → sdd_generate_all_diagrams(feature_number) — 17 diagram types
    → auto-checkpoint.sh snapshots
    → sdd_advance_phase → Phase 5
```

---

### Phase 5 — Tasks

| Element | Value |
|---------|-------|
| **Purpose** | Decompose design into sequenced implementation tasks with effort estimates |
| **Agent** | `task-planner` (existing) |
| **Skill loaded** | `sdd-spec-engineer` (task section) |
| **Primary tools** | `sdd_write_tasks` |
| **Supporting tools** | `sdd_export_work_items` (GitHub/Azure/Jira), `sdd_create_branch` |
| **Hook (after)** | `task-tracer.sh` — detect tasks missing REQ-* traceability |
| **Hook (after)** | `auto-checkpoint.sh` — snapshot tasks |
| **Model** | `claude-sonnet-4-6` (decomposition, not deep reasoning) |
| **Artifact** | `TASKS.md` |
| **Gate** | Every task traces to ≥1 requirement, [P] markers present, effort estimates present |
| **Input** | DESIGN.md + SPECIFICATION.md |
| **Output** | TASKS.md with phased tasks, dependencies, [P] parallel markers, pre-implementation gates |

**Workflow:**
```
DESIGN.md + SPECIFICATION.md
    → sdd_write_tasks(feature_number, tasks_content_from_agent)
    → task-tracer.sh validates REQ-* traceability
    → auto-checkpoint.sh snapshots
    → [optional] sdd_export_work_items(platform) → GitHub Issues / Azure Boards / Jira
    → [optional] sdd_create_branch → branch naming convention
    → sdd_advance_phase → Phase 6
```

---

### Phase 6 — Implement

| Element | Value |
|---------|-------|
| **Purpose** | Generate implementation plan, IaC, dev environments, checklists |
| **Agent** | `implementer` (NEW) |
| **Skill loaded** | `implementer` (NEW — implementation methodology, code quality patterns) |
| **Primary tools** | `sdd_implement`, `sdd_checklist` |
| **Supporting tools** | `sdd_generate_iac`, `sdd_generate_dockerfile`, `sdd_generate_devcontainer`, `sdd_setup_local_env`, `sdd_setup_codespaces`, `sdd_generate_tests`, `sdd_generate_pbt` |
| **Hook (before)** | None — implementation is human-driven |
| **Hook (during)** | `spec-sync.sh` — drift detection on every code change |
| **Model** | `claude-sonnet-4-6`, `thinking: false` (implementation: -30% quality, +43% cost with extended thinking per arXiv:2502.08235) |
| **Artifact** | `CHECKLIST.md` + generated code scaffolding |
| **Gate** | Implementation plan reviewed, checklist items present for all domains |
| **Input** | TASKS.md + DESIGN.md + SPECIFICATION.md |
| **Output** | Ordered implementation plan with checkpoints, quality checklists, infrastructure scaffolding |

**Workflow:**
```
TASKS.md + DESIGN.md
    → sdd_implement(feature_number) → ordered implementation plan
    → sdd_checklist(feature_number, domain: "security") → security checklist
    → sdd_checklist(feature_number, domain: "testing") → testing checklist
    → sdd_generate_tests(feature_number, framework) → test stubs with REQ-ID traceability
    → [optional] sdd_generate_pbt → property-based tests
    → [optional] sdd_generate_iac / sdd_generate_dockerfile / sdd_generate_devcontainer
    → Developer writes code (spec-sync.sh monitors drift)
    → sdd_advance_phase → Phase 7
```

---

### Phase 7 — Verify Tests

| Element | Value |
|---------|-------|
| **Purpose** | Run tests, map results to requirements, detect phantom completions |
| **Agent** | `test-verifier` (NEW) |
| **Skill loaded** | `test-verifier` (NEW — test methodology, coverage thresholds, traceability rules) |
| **Primary tools** | `sdd_verify_tests`, `sdd_verify_tasks` |
| **Supporting tools** | `sdd_check_sync`, `sdd_validate_ears` (re-validate after changes) |
| **Hook (after)** | `spec-sync.sh` — flag spec-code drift |
| **Model** | `claude-sonnet-4-6` (test analysis, not deep reasoning) |
| **Artifact** | `VERIFICATION.md` |
| **Gate** | ≥90% test pass rate, every P0 requirement has passing test, no phantom completions |
| **Input** | Test results (Vitest JSON / pytest JSON / JUnit XML) + SPECIFICATION.md + TASKS.md |
| **Output** | VERIFICATION.md with per-requirement traceability, failure details, suggested fix prompts |

**Workflow:**
```
Developer runs tests → JSON/XML output
    → sdd_verify_tests(feature_number, test_results_path)
        → TestResultParser auto-detects format
        → TestTraceabilityMapper maps tests to REQ-IDs
    → sdd_verify_tasks(feature_number) → detect phantom completions
    → sdd_check_sync(feature_number) → drift detection
    → VERIFICATION.md written
    → sdd_advance_phase → Phase 8
```

---

### Phase 8 — Review

| Element | Value |
|---------|-------|
| **Purpose** | Full quality gate: traceability matrix, compliance, cross-analysis, cognitive debt |
| **Agent** | `spec-reviewer` (existing — enhanced) |
| **Skill loaded** | `sdd-spec-engineer` (quality gate section) |
| **Primary tools** | `sdd_run_analysis`, `sdd_compliance_check`, `sdd_cross_analyze` |
| **Supporting tools** | `sdd_metrics`, `sdd_detect_drift`, `sdd_context_status` |
| **Hook (after)** | `cognitive-debt-alert.sh` — LGTM-without-modification rate |
| **Hook (after)** | `drift-monitor.sh` — constitution drift score |
| **Model** | `claude-opus-4-6` + extended thinking (complex traceability logic) |
| **Artifact** | `ANALYSIS.md`, `CROSS_ANALYSIS.md`, `COMPLIANCE.md` |
| **Gate** | Analysis gate APPROVE, compliance passes for selected frameworks, cross-analysis consistency ≥80% |
| **Input** | ALL artifacts in `.specs/NNN-feature/` |
| **Output** | Complete quality report with gate decision |

**Workflow:**
```
All artifacts
    → sdd_run_analysis(feature_number) → ANALYSIS.md + gate decision
    → sdd_compliance_check(feature_number, frameworks) → COMPLIANCE.md
    → sdd_cross_analyze(feature_number) → CROSS_ANALYSIS.md
    → sdd_metrics(feature_number) → cognitive debt score + HTML dashboard
    → sdd_detect_drift(feature_number) → intent drift score
    → cognitive-debt-alert.sh → warn if LGTM rate > 70%
    → drift-monitor.sh → warn if drift > 40
    → IF gate = APPROVE → sdd_advance_phase → Phase 9
    → IF gate = REVISE → loop back to relevant phase
```

---

### Phase 9 — Release

| Element | Value |
|---------|-------|
| **Purpose** | Create PR, generate documentation, export work items, finalize |
| **Agent** | `release-engineer` (NEW) |
| **Skill loaded** | `release-engineer` (NEW — release process, PR templates, docs generation) |
| **Primary tools** | `sdd_create_pr`, `sdd_generate_docs`, `sdd_generate_all_docs` |
| **Supporting tools** | `sdd_generate_api_docs`, `sdd_generate_runbook`, `sdd_generate_onboarding`, `sdd_export_work_items` |
| **Hook (before)** | `security-scan.sh` — **BLOCKING** — OWASP + secrets scan |
| **Hook (before)** | `release-gate.sh` — **BLOCKING** — VERIFICATION.md + 90% pass rate |
| **Hook (after)** | `changelog.sh` — generate CHANGELOG.md entry (advisory) |
| **Model** | `claude-haiku-4-5` (deterministic, template-based output) |
| **Artifact** | PR payload + documentation suite |
| **Gate** | security-scan.sh passes (exit 0), release-gate.sh passes (exit 0) |
| **Input** | All artifacts + VERIFICATION.md + ANALYSIS.md |
| **Output** | PR ready for merge, full documentation generated |

**Workflow:**
```
All artifacts pass Review gate
    → security-scan.sh — MUST PASS (exit 0)
    → release-gate.sh — MUST PASS (exit 0)
    → sdd_generate_all_docs(feature_number) → parallel doc generation
    → sdd_create_pr(feature_number) → PR payload for GitHub MCP
    → [optional] sdd_export_work_items → close/update work items
    → changelog.sh generates entry
    → DONE — feature delivered
```

---

## 4. Complete Plugin Inventory

### 4.1 Agents (7 total)

| # | Agent | Type | Model | Phases | Specky Tools Used | Status |
|---|-------|------|-------|--------|-------------------|--------|
| 1 | **requirements-engineer** | Pre-pipeline | Opus 4.6 + thinking | Before Phase 0 | `sdd_init`, `sdd_scan_codebase` | ✅ EXISTS |
| 2 | **research-analyst** | Pipeline | Sonnet 4.6 | Phase 1 | `sdd_research`, `sdd_scan_codebase`, `sdd_check_ecosystem`, `sdd_import_document`, `sdd_import_transcript`, `sdd_figma_to_spec` | 🆕 NEW |
| 3 | **spec-engineer** | Pipeline | Opus 4.6 + thinking | Phases 2-3 | `sdd_write_spec`, `sdd_clarify`, `sdd_validate_ears`, `sdd_turnkey_spec`, `sdd_generate_user_stories` | ✅ EXISTS |
| 4 | **design-architect** | Pipeline | Opus 4.6 + thinking | Phase 4 | `sdd_write_design`, `sdd_generate_diagram`, `sdd_generate_all_diagrams`, `sdd_figma_diagram` | ✅ EXISTS |
| 5 | **task-planner** | Pipeline | Sonnet 4.6 | Phase 5 | `sdd_write_tasks`, `sdd_export_work_items`, `sdd_create_branch` | ✅ EXISTS |
| 6 | **implementer** | Pipeline | Sonnet 4.6, thinking: false | Phase 6 | `sdd_implement`, `sdd_checklist`, `sdd_generate_iac`, `sdd_generate_dockerfile`, `sdd_generate_devcontainer`, `sdd_generate_tests`, `sdd_generate_pbt`, `sdd_setup_local_env`, `sdd_setup_codespaces` | 🆕 NEW |
| 7 | **test-verifier** | Pipeline | Sonnet 4.6 | Phase 7 | `sdd_verify_tests`, `sdd_verify_tasks`, `sdd_check_sync` | 🆕 NEW |
| — | **spec-reviewer** | Cross-cutting | Opus 4.6 + thinking | Phases 2, 8 | `sdd_clarify`, `sdd_validate_ears`, `sdd_run_analysis`, `sdd_compliance_check`, `sdd_cross_analyze`, `sdd_metrics`, `sdd_detect_drift` | ✅ EXISTS (enhanced) |
| — | **release-engineer** | Pipeline | Haiku 4.5 | Phase 9 | `sdd_create_pr`, `sdd_generate_docs`, `sdd_generate_all_docs`, `sdd_generate_api_docs`, `sdd_generate_runbook`, `sdd_generate_onboarding`, `sdd_export_work_items` | 🆕 NEW |

**Total: 4 existing + 4 new = 8 agents** (spec-reviewer is existing but enhanced)

---

### 4.2 Skills (7 total)

| # | Skill | Loaded By | Knowledge Domain | Status |
|---|-------|-----------|------------------|--------|
| 1 | **requirements-engineer** | requirements-engineer agent | FRD/NFRD templates, gap detection, 24 validation checks, project type detection | ✅ EXISTS |
| 2 | **sdd-spec-engineer** | spec-engineer, design-architect, task-planner, spec-reviewer | EARS notation, spec templates, design patterns, task decomposition, quality gates | ✅ EXISTS |
| 3 | **research-analyst** | research-analyst agent | Research question taxonomy, tech radar classification, ecosystem evaluation criteria, competitive analysis framework | 🆕 NEW |
| 4 | **implementer** | implementer agent | Implementation methodology, code quality patterns, IaC best practices, test framework selection guide, dev environment setup | 🆕 NEW |
| 5 | **test-verifier** | test-verifier agent | Test methodology, coverage thresholds per project type, traceability rules, phantom completion detection patterns, TDD loop guidance (arXiv:2404.10100) | 🆕 NEW |
| 6 | **release-engineer** | release-engineer agent | Release process, PR templates, documentation generation patterns, changelog format, semantic versioning rules | 🆕 NEW |
| 7 | **compliance-pack** | spec-reviewer agent | Framework-specific controls (HIPAA, SOC2, GDPR, PCI-DSS, ISO27001), keyword mapping, mandatory vs advisory controls | 🆕 NEW (extracted from built-in compliance-engine) |

**Total: 2 existing + 5 new = 7 skills**

---

### 4.3 Prompts / Commands (15 total)

These are the `/sdd:*` commands for Claude Code AND the `@agent` invocations for Copilot.

| # | Command | Agent Invoked | Primary Tool | Phase | Status |
|---|---------|--------------|--------------|-------|--------|
| 1 | `/sdd:requirements` | requirements-engineer | (pre-pipeline, produces FRD+NFRD) | Pre-0 | 🆕 NEW |
| 2 | `/sdd:init` | (direct) | `sdd_init` | 0 | 🆕 NEW |
| 3 | `/sdd:research` | research-analyst | `sdd_research`, `sdd_scan_codebase` | 1 | 🆕 NEW |
| 4 | `/sdd:spec` | spec-engineer | `sdd_write_spec` | 3 | ✅ EXISTS |
| 5 | `/sdd:clarify` | spec-reviewer | `sdd_clarify`, `sdd_validate_ears` | 2 | 🆕 NEW |
| 6 | `/sdd:design` | design-architect | `sdd_write_design` | 4 | ✅ EXISTS |
| 7 | `/sdd:tasks` | task-planner | `sdd_write_tasks` | 5 | ✅ EXISTS |
| 8 | `/sdd:implement` | implementer | `sdd_implement`, `sdd_checklist` | 6 | 🆕 NEW |
| 9 | `/sdd:test` | test-verifier | `sdd_generate_tests`, `sdd_verify_tests` | 7 | 🆕 NEW (replaces `/sdd:verify`) |
| 10 | `/sdd:analyze` | spec-reviewer | `sdd_run_analysis` | 8 | ✅ EXISTS |
| 11 | `/sdd:release` | release-engineer | `sdd_create_pr`, `sdd_generate_all_docs` | 9 | 🆕 NEW |
| 12 | `/sdd:bugfix` | spec-reviewer | `sdd_write_bugfix` | Any | ✅ EXISTS |
| 13 | `/sdd:diagrams` | design-architect | `sdd_generate_all_diagrams` | Any | ✅ EXISTS |
| 14 | `/sdd:iac` | implementer | `sdd_generate_iac` | 6 | ✅ EXISTS (reassigned to implementer) |
| 15 | `/sdd:docs` | release-engineer | `sdd_generate_all_docs` | 9 | ✅ EXISTS (reassigned to release-engineer) |

**Total: 7 existing + 8 new = 15 prompts/commands**

---

### 4.4 Hooks (10 total — all exist, 2 enhanced)

| # | Hook | Phase | Type | Enhancement Needed |
|---|------|-------|------|--------------------|
| 1 | `spec-sync.sh` | 6 (during impl) | Advisory | None — works |
| 2 | `security-scan.sh` | 9 (before release) | **Blocking** | None — works |
| 3 | `release-gate.sh` | 9 (before PR) | **Blocking** | None — works |
| 4 | `auto-checkpoint.sh` | 0,3,4,5 (after writes) | Advisory | None — works |
| 5 | `spec-quality.sh` | 3 (after spec) | Advisory | None — works |
| 6 | `task-tracer.sh` | 5 (after tasks) | Advisory | None — works |
| 7 | `ears-validator.sh` | 2 (after clarify) | Advisory | 🔄 ENHANCE: call after Phase 2, not just Phase 3 |
| 8 | `drift-monitor.sh` | 8 (after review) | Advisory | None — works |
| 9 | `cognitive-debt-alert.sh` | 8 (after review) | Advisory | None — works |
| 10 | `metrics-dashboard.sh` | 8 (after review) | Advisory | None — works |

**Total: 10 existing (2 need minor enhancement)**

---

### 4.5 Instructions (2 total — both exist, need update)

| # | File | Platform | Purpose | Update Needed |
|---|------|----------|---------|---------------|
| 1 | `CLAUDE.md` | Claude Code | Session context, tool inventory, model routing, conventions | 🔄 Update to v3.2.0 tool count (57), add plugin section |
| 2 | `.github/copilot-instructions.md` | GitHub Copilot | Same but for Copilot context | 🔄 Update to match CLAUDE.md |

---

### 4.6 References (3 total — all exist)

| # | File | Loaded By | Purpose |
|---|------|-----------|---------|
| 1 | `references/ears-notation.md` | spec-engineer, spec-reviewer | EARS syntax guide with 6 patterns |
| 2 | `references/spec-templates.md` | spec-engineer, design-architect | Artifact templates |
| 3 | `references/design-patterns.md` | design-architect | Architecture patterns |

---

## 5. Plugin Manifest Spec

Every plugin ships with a `specky-plugin.yml` at its root:

```yaml
# specky-plugin.yml — v1.0.0 manifest specification

name: "@specky/requirements-engineer"   # npm-style scoped name
version: "1.0.0"                        # semver
type: agent                             # agent | skill | hook | template-pack | compliance-pack | reference
specky_min_version: "3.2.0"             # minimum Specky version
description: "Senior requirements engineer. Produces FRD + NFRD ready for sdd_init."

# Where to install files (dual-target)
targets:
  copilot:
    - src: agent.md
      dest: .github/agents/requirements-engineer.agent.md
  claude_code:
    - src: prompt.md
      dest: .claude/commands/requirements-engineer.md
  skill:
    - src: SKILL.md
      dest: .specky/skills/requirements-engineer/SKILL.md

# Model routing metadata
model:
  default: claude-opus-4-6
  thinking: true
  rationale: "Requirements analysis — high ambiguity, errors cascade. arXiv:2502.08235."

# Which Specky tools this plugin uses (for dependency validation)
uses_tools:
  - sdd_init
  - sdd_scan_codebase

# Phases this plugin operates in
phases: [0]

# Dependencies on other plugins
depends_on: []

# What this plugin produces (for handoff validation)
produces:
  - "docs/requirements/FRD_*.md"
  - "docs/requirements/NFRD_*.md"

# What this plugin consumes (for handoff validation)
consumes: []
```

---

## 6. File Tree

The complete plugin ecosystem installed in a project:

```
project-root/
├── .github/
│   ├── copilot-instructions.md          ← INSTRUCTION (Copilot context)
│   └── agents/
│       ├── requirements-engineer.agent.md   ← AGENT (Phase 0)
│       ├── research-analyst.agent.md        ← AGENT (Phase 1) 🆕
│       ├── spec-engineer.agent.md           ← AGENT (Phases 2-3)
│       ├── design-architect.agent.md        ← AGENT (Phase 4)
│       ├── task-planner.agent.md            ← AGENT (Phase 5)
│       ├── implementer.agent.md             ← AGENT (Phase 6) 🆕
│       ├── test-verifier.agent.md           ← AGENT (Phase 7) 🆕
│       ├── spec-reviewer.agent.md           ← AGENT (Phases 2, 8)
│       └── release-engineer.agent.md        ← AGENT (Phase 9) 🆕
│
├── .claude/
│   └── commands/
│       ├── sdd-requirements.md              ← PROMPT /sdd:requirements 🆕
│       ├── sdd-init.md                      ← PROMPT /sdd:init 🆕
│       ├── sdd-research.md                  ← PROMPT /sdd:research 🆕
│       ├── sdd-spec.md                      ← PROMPT /sdd:spec
│       ├── sdd-clarify.md                   ← PROMPT /sdd:clarify 🆕
│       ├── sdd-design.md                    ← PROMPT /sdd:design
│       ├── sdd-tasks.md                     ← PROMPT /sdd:tasks
│       ├── sdd-implement.md                 ← PROMPT /sdd:implement 🆕
│       ├── sdd-test.md                      ← PROMPT /sdd:test 🆕
│       ├── sdd-analyze.md                   ← PROMPT /sdd:analyze
│       ├── sdd-release.md                   ← PROMPT /sdd:release 🆕
│       ├── sdd-bugfix.md                    ← PROMPT /sdd:bugfix
│       ├── sdd-diagrams.md                  ← PROMPT /sdd:diagrams
│       ├── sdd-iac.md                       ← PROMPT /sdd:iac
│       └── sdd-docs.md                      ← PROMPT /sdd:docs
│
├── .specky/
│   ├── config.yml                           ← CONFIG (project settings)
│   ├── plugins.yml                          ← PLUGIN REGISTRY (installed plugins) 🆕
│   ├── skills/
│   │   ├── requirements-engineer/SKILL.md
│   │   ├── research-analyst/SKILL.md        🆕
│   │   ├── sdd-spec-engineer/SKILL.md
│   │   ├── implementer/SKILL.md             🆕
│   │   ├── test-verifier/SKILL.md           🆕
│   │   ├── release-engineer/SKILL.md        🆕
│   │   └── compliance-pack/SKILL.md         🆕
│   └── hooks/
│       ├── spec-sync.sh
│       ├── security-scan.sh
│       ├── release-gate.sh
│       ├── auto-checkpoint.sh
│       ├── spec-quality.sh
│       ├── task-tracer.sh
│       ├── ears-validator.sh
│       ├── drift-monitor.sh
│       ├── cognitive-debt-alert.sh
│       └── metrics-dashboard.sh
│
├── CLAUDE.md                                ← INSTRUCTION (Claude Code context)
│
├── references/
│   ├── ears-notation.md                     ← REFERENCE
│   ├── spec-templates.md                    ← REFERENCE
│   └── design-patterns.md                   ← REFERENCE
│
└── .specs/                                  ← ARTIFACTS (pipeline output)
    └── 001-feature-name/
        ├── CONSTITUTION.md
        ├── RESEARCH.md
        ├── SPECIFICATION.md
        ├── DESIGN.md
        ├── TASKS.md
        ├── CHECKLIST.md
        ├── VERIFICATION.md
        ├── ANALYSIS.md
        ├── CROSS_ANALYSIS.md
        └── COMPLIANCE.md
```

**Total files: 9 agents + 15 prompts + 7 skills + 10 hooks + 2 instructions + 3 references = 46 files**

---

## 7. Handoff Contracts Between Plugins

Each agent produces output that becomes the next agent's input. These contracts must be explicit:

```
┌──────────────────────┐     FRD + NFRD      ┌──────────────────────┐
│ requirements-engineer ├────────────────────►│      sdd_init        │
│  (pre-pipeline)      │                      │   (Phase 0 tool)     │
└──────────────────────┘                      └──────────┬───────────┘
                                                         │ CONSTITUTION.md
                                                         ▼
                                              ┌──────────────────────┐
                                              │  research-analyst    │
                                              │   (Phase 1)          │
                                              └──────────┬───────────┘
                                                         │ RESEARCH.md
                                                         ▼
                              ┌───────────────────────────────────────────┐
                              │         spec-engineer ↔ spec-reviewer     │
                              │        (Phases 2-3 — clarify/specify loop)│
                              └──────────────────┬────────────────────────┘
                                                 │ SPECIFICATION.md
                                                 ▼
                                      ┌──────────────────────┐
                                      │  design-architect    │
                                      │   (Phase 4)          │
                                      └──────────┬───────────┘
                                                 │ DESIGN.md
                                                 ▼
                                      ┌──────────────────────┐
                                      │   task-planner       │
                                      │   (Phase 5)          │
                                      └──────────┬───────────┘
                                                 │ TASKS.md
                                                 ▼
                                      ┌──────────────────────┐
                                      │   implementer        │
                                      │   (Phase 6)          │
                                      └──────────┬───────────┘
                                                 │ Code + CHECKLIST.md
                                                 ▼
                                      ┌──────────────────────┐
                                      │   test-verifier      │
                                      │   (Phase 7)          │
                                      └──────────┬───────────┘
                                                 │ VERIFICATION.md
                                                 ▼
                                      ┌──────────────────────┐
                                      │   spec-reviewer      │
                                      │   (Phase 8 — review) │
                                      └──────────┬───────────┘
                                                 │ ANALYSIS.md + gate decision
                                                 ▼
                                      ┌──────────────────────┐
                                      │  release-engineer    │
                                      │   (Phase 9)          │
                                      └──────────────────────┘
                                                 │ PR + docs
                                                 ▼ DONE
```

### Handoff Data Format

Every handoff is a file in `.specs/NNN-feature/`. No API calls between agents. No shared memory. File-based communication per ADR-001.

| From | To | Handoff File | Required Fields |
|------|----|-------------|-----------------|
| requirements-engineer → sdd_init | Phase 0 | `docs/requirements/FRD_*.md` + `NFRD_*.md` | Feature name, description, constraints |
| sdd_init → research-analyst | Phase 1 | `CONSTITUTION.md` | Project scope, stakeholders |
| research-analyst → spec-engineer | Phase 3 | `RESEARCH.md` | Answered questions, tech stack |
| spec-engineer ↔ spec-reviewer | Phase 2-3 | `SPECIFICATION.md` | EARS requirements, priorities |
| spec-engineer → design-architect | Phase 4 | `SPECIFICATION.md` | All requirements with acceptance criteria |
| design-architect → task-planner | Phase 5 | `DESIGN.md` | Components, interfaces, ADRs |
| task-planner → implementer | Phase 6 | `TASKS.md` | Sequenced tasks, dependencies |
| implementer → test-verifier | Phase 7 | Code + `CHECKLIST.md` | Implementation + checklists |
| test-verifier → spec-reviewer | Phase 8 | `VERIFICATION.md` | Test results, coverage map |
| spec-reviewer → release-engineer | Phase 9 | `ANALYSIS.md` + gate decision | APPROVE/REVISE |

---

## 8. What Exists vs What Must Be Built

### Summary

| Category | Exists | New | Total |
|----------|--------|-----|-------|
| Agents | 4 (spec-engineer, design-architect, task-planner, spec-reviewer) + 1 (requirements-engineer) | 4 (research-analyst, implementer, test-verifier, release-engineer) | 9 |
| Skills | 2 (requirements-engineer, sdd-spec-engineer) | 5 (research-analyst, implementer, test-verifier, release-engineer, compliance-pack) | 7 |
| Prompts | 7 (/sdd:spec, design, tasks, analyze, bugfix, diagrams, iac, docs) | 8 (/sdd:requirements, init, research, clarify, implement, test, release + iac/docs reassignment) | 15 |
| Hooks | 10 | 0 (2 minor enhancements) | 10 |
| Instructions | 2 (CLAUDE.md, copilot-instructions) | 0 (updates only) | 2 |
| References | 3 | 0 | 3 |
| **TOTAL** | **28** | **17** | **46** |

### Detailed New Build List

| Priority | Item | Type | Effort | Why |
|----------|------|------|--------|-----|
| **P0** | `implementer.agent.md` + `implementer.prompt.md` + `implementer/SKILL.md` | Agent + Skill + Prompt | M | Phase 6 has no dedicated agent — biggest gap |
| **P0** | `test-verifier.agent.md` + `test-verifier.prompt.md` + `test-verifier/SKILL.md` | Agent + Skill + Prompt | M | Phase 7 has no dedicated agent — verification is critical |
| **P0** | `release-engineer.agent.md` + `release-engineer.prompt.md` + `release-engineer/SKILL.md` | Agent + Skill + Prompt | S | Phase 9 has no agent — release is gated by blocking hooks |
| **P1** | `research-analyst.agent.md` + `research-analyst.prompt.md` + `research-analyst/SKILL.md` | Agent + Skill + Prompt | M | Phase 1 uses tools but has no specialized agent |
| **P1** | `/sdd:clarify` command | Prompt | S | Phase 2 has no dedicated entry point |
| **P1** | `/sdd:init` command | Prompt | S | Phase 0 has no dedicated entry point |
| **P2** | `compliance-pack/SKILL.md` | Skill | M | Extract compliance knowledge from built-in engine into pluggable skill |
| **P2** | `specky-plugin.yml` manifest spec | Spec | S | Foundation for future plugin system |
| **P2** | `.specky/plugins.yml` registry file | Config | S | Track installed plugins |
| **P3** | Update CLAUDE.md to v3.2.0 | Instruction | S | Reflect current tool count and plugin ecosystem |
| **P3** | Update `.github/copilot-instructions.md` | Instruction | S | Match CLAUDE.md |

---

## 9. Implementation Phases

### Phase A — Foundation (P0 agents for Phases 6, 7, 9)

Build the 3 missing pipeline agents that cover the code → test → release gap.

**Deliverables:**
1. `implementer.agent.md` + `.claude/commands/sdd-implement.md` + `.specky/skills/implementer/SKILL.md`
2. `test-verifier.agent.md` + `.claude/commands/sdd-test.md` + `.specky/skills/test-verifier/SKILL.md`
3. `release-engineer.agent.md` + `.claude/commands/sdd-release.md` + `.specky/skills/release-engineer/SKILL.md`

**Why first:** These phases exist in the state machine but have no orchestration layer. Developers fall back to raw tool calls, losing the guided workflow.

### Phase B — Complete Coverage (P1 — Phases 0, 1, 2)

Fill the remaining gaps in early pipeline phases.

**Deliverables:**
1. `research-analyst.agent.md` + `.claude/commands/sdd-research.md` + `.specky/skills/research-analyst/SKILL.md`
2. `.claude/commands/sdd-clarify.md` (thin prompt, uses spec-reviewer agent)
3. `.claude/commands/sdd-init.md` (thin prompt, direct tool call)

### Phase C — Plugin Infrastructure (P2)

Establish the plugin manifest and registry.

**Deliverables:**
1. `specky-plugin.yml` spec document
2. `.specky/plugins.yml` format
3. `compliance-pack/SKILL.md` (first extracted plugin)
4. `sdd_install_agent` MCP tool (v3.3)

### Phase D — Polish (P3)

Update instructions and documentation.

**Deliverables:**
1. CLAUDE.md v3.2.0 update
2. `.github/copilot-instructions.md` v3.2.0 update
3. README plugin ecosystem section

---

## 10. Anti-Patterns

| Anti-Pattern | Why It's Wrong | Correct Approach |
|-------------|---------------|------------------|
| One mega-agent for all phases | Context collapse, model routing impossible, >200K token prompts | One agent per responsibility domain, model routing per phase |
| Skill that calls tools directly | Skills are knowledge, not actors — they can't call MCP tools | Agent loads skill, applies knowledge through tool calls |
| Hook that invokes LLM | Hooks must be zero-cost shell scripts — LLM calls defeat the purpose | Hook checks file content with grep/jq, agent does reasoning |
| Agent without model routing metadata | Every agent must declare its model — otherwise clients use default (expensive) | YAML frontmatter: `model: claude-opus-4-6`, `thinking: true/false` |
| Prompt that embeds business logic | Prompts are thin entry points — logic lives in skills and agents | Prompt loads skill, passes `$ARGUMENTS` to agent |
| Generating CLAUDE.md or copilot-instructions.md | Per arXiv:2601.20404, LLM-generated AGENTS.md performs -3% vs no file | Always human-authored, never auto-generated |
| Skipping handoff validation | Agent B assumes Agent A's output is correct — it may not be | Gate at `sdd_advance_phase` validates required files and content |
| Plugin without `specky_min_version` | Breaking changes in Specky tools could silently break plugins | Manifest declares minimum version, CLI validates on install |

---

## References

- [Specky GitHub](https://github.com/paulasilvatech/specky)
- [npm: specky-sdd](https://www.npmjs.com/package/specky-sdd)
- arXiv:2502.08235 — Extended thinking harms iterative tasks (-30% quality, +43% cost)
- arXiv:2509.11079 — Difficulty-aware routing (+11.21% accuracy at 64% cost)
- arXiv:2601.20404 — AGENTS.md human curation benefit (-28.64% runtime)
- arXiv:2601.03878 — SDD + TDD Registered Report (human-in-loop gates)
- arXiv:2602.00180 — From Code to Contract (CONSTITUTION as intent artifact)
- arXiv:2404.10100 — TDD interactive loop benefit (+20% pass@1)
- arXiv:2504.11805 — Planner-coder gap (75.3% of MAS failures)
- arXiv:2603.22106 — Cognitive debt measurement
