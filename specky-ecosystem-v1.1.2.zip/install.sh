#!/bin/bash
# Specky SDD Ecosystem Installer — v1.1.1
# Usage:
#   Opção A (recomendada): unzip specky-ecosystem-v1.1.1.zip -d /tmp/specky && bash /tmp/specky/install.sh
#   Opção B (no projeto):  unzip specky-ecosystem-v1.1.1.zip && bash install.sh
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'

# ─── Resolver SCRIPT_DIR e REPO_DIR ──────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Se o usuário rodou o script de dentro do zip extraído no próprio projeto,
# SCRIPT_DIR == REPO_DIR — detectamos isso e usamos um tmpdir como fonte
REPO_DIR="$(pwd)"

if [ "$SCRIPT_DIR" = "$REPO_DIR" ]; then
  # Extraímos para um tmpdir temporário e usamos como fonte
  TMP_SRC=$(mktemp -d)
  cp -r "$SCRIPT_DIR/." "$TMP_SRC/"
  SCRIPT_DIR="$TMP_SRC"
  CLEANUP_TMP=1
else
  CLEANUP_TMP=0
fi

# Cleanup tmpdir on exit
cleanup() { [ "${CLEANUP_TMP:-0}" = "1" ] && rm -rf "$TMP_SRC" 2>/dev/null || true; }
trap cleanup EXIT

echo -e "${BLUE}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     Specky SDD Ecosystem — One-Click Installer          ║${NC}"
echo -e "${BLUE}║     v1.1.1 · dual-target · 3-layer hooks · 19 prompts  ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════╝${NC}"
echo -e "Instalando em: ${GREEN}$REPO_DIR${NC}"
echo -e "Fonte:         ${CYAN}$SCRIPT_DIR${NC}"
echo ""

# ─── Verificar que a fonte tem os arquivos esperados ─────────────────────────
if [ ! -f "$SCRIPT_DIR/.github/agents/implementer.agent.md" ]; then
  echo -e "${RED}✗ Arquivos do pacote não encontrados em: $SCRIPT_DIR${NC}"
  echo -e "  Certifique-se de extrair o zip antes de rodar: unzip specky-ecosystem-v1.1.1.zip -d /tmp/specky"
  exit 1
fi

# ─── [1/10] MCP Server ───────────────────────────────────────────────────────
echo -e "${YELLOW}[1/10] Instalando MCP Server specky-sdd...${NC}"
if ! command -v node &>/dev/null; then
  echo -e "  ${RED}✗${NC} Node.js é obrigatório: https://nodejs.org/"; exit 1
fi
if npm install -g specky-sdd 2>/dev/null; then
  echo -e "  ${GREEN}✓${NC} specky-sdd@3.2.0 instalado globalmente"
else
  echo -e "  ${YELLOW}ℹ${NC} Não foi possível instalar globalmente — será usado via npx"
fi

# ─── [2/10] VS Code MCP ──────────────────────────────────────────────────────
echo -e "${YELLOW}[2/10] Configurando VS Code MCP (.vscode/mcp.json)...${NC}"
mkdir -p "$REPO_DIR/.vscode"
if [ ! -f "$REPO_DIR/.vscode/mcp.json" ]; then
  cp "$SCRIPT_DIR/.vscode/mcp.json" "$REPO_DIR/.vscode/mcp.json"
  echo -e "  ${GREEN}✓${NC} .vscode/mcp.json criado"
else
  echo -e "  ${GREEN}✓${NC} .vscode/mcp.json já existe — mantido"
fi

# ─── [3/10] Claude Code MCP ──────────────────────────────────────────────────
echo -e "${YELLOW}[3/10] Registrando MCP no Claude Code...${NC}"
if command -v claude &>/dev/null; then
  if claude mcp add specky -- npx -y specky-sdd 2>/dev/null; then
    echo -e "  ${GREEN}✓${NC} MCP registrado no Claude Code"
  else
    echo -e "  ${YELLOW}ℹ${NC} Já registrado ou falhou — rode manualmente se necessário:"
    echo -e "  ${CYAN}    claude mcp add specky -- npx -y specky-sdd${NC}"
  fi
else
  echo -e "  ${YELLOW}ℹ${NC} claude CLI não encontrado (opcional)"
  echo -e "  ${CYAN}    Instale em: https://claude.ai/download${NC}"
fi

# ─── [4/10] Agents → .github/agents/ ────────────────────────────────────────
echo -e "${YELLOW}[4/10] Copiando agentes → .github/agents/ (7 agentes)${NC}"
mkdir -p "$REPO_DIR/.github/agents"
cp "$SCRIPT_DIR/.github/agents/"*.md "$REPO_DIR/.github/agents/"
echo -e "  ${GREEN}✓${NC} 7 agentes:"
for f in requirements-engineer.agent.md sdd-init.agent.md research-analyst.agent.md \
          sdd-clarify.agent.md implementer.agent.md test-verifier.agent.md release-engineer.agent.md; do
  if [ -f "$REPO_DIR/.github/agents/$f" ]; then
    echo -e "    ${CYAN}·${NC} $f"
  else
    echo -e "    ${RED}✗${NC} FALTANDO: $f"
  fi
done

# ─── [5/10] Commands → .claude/commands/ ─────────────────────────────────────
echo -e "${YELLOW}[5/10] Copiando comandos → .claude/commands/ (7 comandos)${NC}"
mkdir -p "$REPO_DIR/.claude/commands"
cp "$SCRIPT_DIR/.claude/commands/"*.md "$REPO_DIR/.claude/commands/"
echo -e "  ${GREEN}✓${NC} 7 comandos:"
for f in sdd-requirements.md sdd-init.md sdd-research.md sdd-clarify.md \
          sdd-implement.md sdd-test.md sdd-release.md; do
  name=$(basename "$f" .md | sed 's/sdd-//')
  if [ -f "$REPO_DIR/.claude/commands/$f" ]; then
    echo -e "    ${CYAN}·${NC} /sdd:$name"
  else
    echo -e "    ${RED}✗${NC} FALTANDO: $f"
  fi
done

# ─── [6/10] Skills → .specky/skills/ ────────────────────────────────────────
echo -e "${YELLOW}[6/10] Copiando skills → .specky/skills/ (5 skills, compartilhadas)${NC}"
for skill in implementer test-verifier release-engineer research-analyst sdd-markdown-standard; do
  mkdir -p "$REPO_DIR/.specky/skills/$skill"
  cp "$SCRIPT_DIR/.specky/skills/$skill/SKILL.md" "$REPO_DIR/.specky/skills/$skill/SKILL.md"
done
echo -e "  ${GREEN}✓${NC} 5 skills copiadas para .specky/skills/"

# ─── [7/10] Hook scripts → .specky/hooks/ (compartilhados) ──────────────────
echo -e "${YELLOW}[7/10] Copiando hook scripts → .specky/hooks/ (10 scripts, compartilhados)${NC}"
mkdir -p "$REPO_DIR/.specky/hooks"
cp "$SCRIPT_DIR/.specky/hooks/"*.sh "$REPO_DIR/.specky/hooks/"
chmod +x "$REPO_DIR/.specky/hooks/"*.sh
HOOK_COUNT=$(ls "$REPO_DIR/.specky/hooks/"*.sh | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $HOOK_COUNT scripts em .specky/hooks/ — BLOCKING: security-scan, release-gate"

# ─── [8/10] GitHub Actions → .github/workflows/ ──────────────────────────────
echo -e "${YELLOW}[8/10] Copiando GitHub Actions → .github/workflows/ (10 workflows)${NC}"
mkdir -p "$REPO_DIR/.github/workflows"
cp "$SCRIPT_DIR/.github/workflows/"*.yml "$REPO_DIR/.github/workflows/"
WF_COUNT=$(ls "$REPO_DIR/.github/workflows/"*.yml | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $WF_COUNT workflows copiados para .github/workflows/"

# ─── [9/10] Hook configs (3 plataformas) ─────────────────────────────────────
echo -e "${YELLOW}[9/10] Configurando hooks nas 3 plataformas...${NC}"

# 9a: Claude Code → .claude/settings.json
mkdir -p "$REPO_DIR/.claude"
if [ -f "$REPO_DIR/.claude/settings.json" ]; then
  cp "$REPO_DIR/.claude/settings.json" "$REPO_DIR/.claude/settings.json.bak"
  echo -e "  ${CYAN}ℹ${NC}  Backup criado: .claude/settings.json.bak"
fi
cp "$SCRIPT_DIR/.claude/settings.json" "$REPO_DIR/.claude/settings.json"
echo -e "  ${GREEN}✓${NC} .claude/settings.json         (Claude Code)"

# 9b: GitHub Copilot CLI/Cloud → .github/hooks/sdd-hooks.json
mkdir -p "$REPO_DIR/.github/hooks"
cp "$SCRIPT_DIR/.github/hooks/sdd-hooks.json" "$REPO_DIR/.github/hooks/sdd-hooks.json"
echo -e "  ${GREEN}✓${NC} .github/hooks/sdd-hooks.json  (Copilot CLI + Cloud)"

# 9c: VS Code Copilot → .vscode/settings.json (merge, não substituir)
mkdir -p "$REPO_DIR/.vscode"
if [ -f "$REPO_DIR/.vscode/settings.json" ]; then
  if command -v python3 &>/dev/null; then
    python3 - "$REPO_DIR/.vscode/settings.json" "$SCRIPT_DIR/.vscode/settings.json" << 'PYEOF'
import json, sys
with open(sys.argv[1]) as f: existing = json.load(f)
with open(sys.argv[2]) as f: new = json.load(f)
def deep_merge(base, override):
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = deep_merge(result[k], v)
        else:
            result[k] = v
    return result
merged = deep_merge(existing, new)
with open(sys.argv[1], 'w') as f: json.dump(merged, f, indent=2)
PYEOF
    echo -e "  ${GREEN}✓${NC} .vscode/settings.json         (VS Code Copilot — merged)"
  else
    cp "$SCRIPT_DIR/.vscode/settings.json" "$REPO_DIR/.vscode/settings.json"
    echo -e "  ${YELLOW}ℹ${NC}  .vscode/settings.json         (VS Code Copilot — substituído, python3 ausente)"
  fi
else
  cp "$SCRIPT_DIR/.vscode/settings.json" "$REPO_DIR/.vscode/settings.json"
  echo -e "  ${GREEN}✓${NC} .vscode/settings.json         (VS Code Copilot — criado)"
fi

# 9d: Prompts → .claude/prompts/ + .github/prompts/
mkdir -p "$REPO_DIR/.claude/prompts"
mkdir -p "$REPO_DIR/.github/prompts"
cp "$SCRIPT_DIR/.claude/prompts/"*.md "$REPO_DIR/.claude/prompts/"
cp "$SCRIPT_DIR/.github/prompts/"*.md "$REPO_DIR/.github/prompts/"
PROMPT_COUNT=$(ls "$REPO_DIR/.claude/prompts/"*.md | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $PROMPT_COUNT prompts → .claude/prompts/  (Claude Code: /specky:*)"
echo -e "  ${GREEN}✓${NC} $PROMPT_COUNT prompts → .github/prompts/  (Copilot: copiar e colar)"

# ─── [10/10] Config do projeto + docs + verificação ──────────────────────────
echo -e "${YELLOW}[10/10] Configuração do projeto + docs + verificação...${NC}"

# .specky/config.yml
if [ ! -f "$REPO_DIR/.specky/config.yml" ]; then
  cp "$SCRIPT_DIR/.specky/config.yml" "$REPO_DIR/.specky/config.yml"
  echo -e "  ${GREEN}✓${NC} .specky/config.yml criado"
else
  echo -e "  ${GREEN}✓${NC} .specky/config.yml já existe"
fi

# Documentação → raiz do projeto
for doc in GETTING-STARTED.md INSTALL.md HOOKS-README.md \
           "Specky_Plugin_Ecosystem_Blueprint_v1_0_0_2026-04-13.md"; do
  if [ -f "$SCRIPT_DIR/$doc" ]; then
    cp "$SCRIPT_DIR/$doc" "$REPO_DIR/$doc"
    echo -e "  ${GREEN}✓${NC} $doc"
  else
    echo -e "  ${YELLOW}ℹ${NC}  $doc não encontrado na fonte (ignorado)"
  fi
done

# ─── Verificação completa ─────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}  Verificando arquivos instalados...${NC}"
echo ""

T=0; P=0; FAIL=()

check() {
  local path="$1"
  local label="$2"
  T=$((T+1))
  if [ -f "$REPO_DIR/$path" ]; then
    P=$((P+1))
    echo -e "    ${GREEN}✓${NC} $label"
  else
    FAIL+=("$path")
    echo -e "    ${RED}✗${NC} FALTANDO: $label"
  fi
}

echo -e "  ${CYAN}Agentes (7):${NC}"
check ".github/agents/requirements-engineer.agent.md" "@requirements-engineer"
check ".github/agents/sdd-init.agent.md"              "@sdd-init"
check ".github/agents/research-analyst.agent.md"      "@research-analyst"
check ".github/agents/sdd-clarify.agent.md"           "@sdd-clarify"
check ".github/agents/implementer.agent.md"           "@implementer"
check ".github/agents/test-verifier.agent.md"         "@test-verifier"
check ".github/agents/release-engineer.agent.md"      "@release-engineer"

echo -e "  ${CYAN}Comandos Claude Code (7):${NC}"
check ".claude/commands/sdd-requirements.md"  "/sdd:requirements"
check ".claude/commands/sdd-init.md"          "/sdd:init"
check ".claude/commands/sdd-research.md"      "/sdd:research"
check ".claude/commands/sdd-clarify.md"       "/sdd:clarify"
check ".claude/commands/sdd-implement.md"     "/sdd:implement"
check ".claude/commands/sdd-test.md"          "/sdd:test"
check ".claude/commands/sdd-release.md"       "/sdd:release"

echo -e "  ${CYAN}Skills (5):${NC}"
for s in implementer test-verifier release-engineer research-analyst sdd-markdown-standard; do
  check ".specky/skills/$s/SKILL.md" "$s"
done

echo -e "  ${CYAN}Hook scripts (10):${NC}"
for h in spec-sync security-scan release-gate auto-checkpoint spec-quality \
          task-tracer ears-validator drift-monitor cognitive-debt-alert metrics-dashboard; do
  check ".specky/hooks/$h.sh" "$h.sh"
done

echo -e "  ${CYAN}GitHub Actions (10):${NC}"
for h in spec-sync security-scan release-gate auto-checkpoint spec-quality \
          task-tracer ears-validator drift-monitor cognitive-debt-alert metrics-dashboard; do
  check ".github/workflows/$h.yml" "$h.yml"
done

echo -e "  ${CYAN}Hook configs (3 plataformas):${NC}"
check ".claude/settings.json"            "Claude Code hooks"
check ".github/hooks/sdd-hooks.json"     "Copilot CLI/Cloud hooks"
check ".vscode/settings.json"            "VS Code Copilot hooks"

echo -e "  ${CYAN}VS Code MCP:${NC}"
check ".vscode/mcp.json" "VS Code MCP config"

echo -e "  ${CYAN}Prompts (spot-check 5 de 19):${NC}"
for p in specky-greenfield.md specky-brownfield.md specky-research.md \
          specky-debug-hook.md specky-pipeline-status.md; do
  check ".claude/prompts/$p" "$p"
done

echo -e "  ${CYAN}Projeto config:${NC}"
check ".specky/config.yml"   ".specky/config.yml"

echo -e "  ${CYAN}Documentação:${NC}"
check "GETTING-STARTED.md"    "GETTING-STARTED.md"
check "INSTALL.md"            "INSTALL.md"
check "HOOKS-README.md"       "HOOKS-README.md"

# ─── Resultado ───────────────────────────────────────────────────────────────
echo ""
if [ "$P" -eq "$T" ]; then
  echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║  ✅  $P/$T verificações — Specky pronto para usar!     ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
else
  echo -e "${RED}╔══════════════════════════════════════════════════════════╗${NC}"
  echo -e "${RED}║  ⚠️   $P/$T — alguns arquivos não foram instalados       ║${NC}"
  echo -e "${RED}╚══════════════════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "${RED}Arquivos faltando:${NC}"
  for f in "${FAIL[@]}"; do echo -e "  ${RED}✗${NC} $f"; done
  echo ""
  echo -e "Tente novamente com: ${CYAN}unzip specky-ecosystem-v1.1.1.zip -d /tmp/specky && bash /tmp/specky/install.sh${NC}"
fi

echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}  Como começar${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e ""
echo -e "  ${CYAN}Leia primeiro:${NC}  GETTING-STARTED.md"
echo -e ""
echo -e "  ${CYAN}Claude Code:${NC}"
echo -e "    /specky:greenfield   → Projeto novo do zero"
echo -e "    /specky:brownfield   → Nova feature em sistema existente"
echo -e "    /specky:status       → Status do pipeline atual"
echo -e ""
echo -e "  ${CYAN}VS Code + Copilot:${NC}"
echo -e "    @sdd-init            → Fase 0: inicializar pipeline"
echo -e "    @research-analyst    → Fase 1: pesquisa e discovery"
echo -e "    @implementer         → Fase 6: implementação"
echo -e "    @release-engineer    → Fase 9: release e PR"
echo -e ""
echo -e "  ${CYAN}Prompts prontos:${NC}  .claude/prompts/specky-*.md  e  .github/prompts/specky-*.md"
echo -e ""
