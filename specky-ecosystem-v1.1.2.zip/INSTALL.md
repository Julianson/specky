---
title: "Specky Plugin Ecosystem — Phase A+B Delivery"
description: "Installation guide and pipeline command map for the 4 new agents, 7 new commands, and 4 new skills."
author: "Paula Silva"
date: "2026-04-13"
version: "1.0.0"
---

# Specky Plugin Ecosystem — Installation Guide

> 15 files that complete the Specky 10-phase pipeline orchestration layer.

---

## What's in This Delivery

### Phase A (P0 — Filling the code→test→release gap)

| Agent | Phase | Files | Model |
|-------|-------|-------|-------|
| **implementer** | 6 — Implement | agent.md + prompt.md + SKILL.md | Sonnet 4.6, thinking: false |
| **test-verifier** | 7 — Verify | agent.md + prompt.md + SKILL.md | Sonnet 4.6 |
| **release-engineer** | 9 — Release | agent.md + prompt.md + SKILL.md | Haiku 4.5 |

### Phase B (P1 — Completing early pipeline + missing commands)

| Agent/Command | Phase | Files | Model |
|---------------|-------|-------|-------|
| **research-analyst** | 1 — Research | agent.md + prompt.md + SKILL.md | Sonnet 4.6 |
| `/sdd:init` | 0 — Init | prompt.md | Haiku 4.5 |
| `/sdd:clarify` | 2 — Clarify | prompt.md | Opus 4.6 + thinking |
| `/sdd:requirements` | Pre-pipeline | prompt.md | Opus 4.6 + thinking |

---

## Installation

### Step 1 — Copy agents to `.github/agents/`

```bash
cp github-agents/implementer.agent.md      YOUR_REPO/.github/agents/
cp github-agents/test-verifier.agent.md     YOUR_REPO/.github/agents/
cp github-agents/release-engineer.agent.md  YOUR_REPO/.github/agents/
cp github-agents/research-analyst.agent.md  YOUR_REPO/.github/agents/
```

### Step 2 — Copy commands to `.claude/commands/`

```bash
cp claude-commands/sdd-implement.md      YOUR_REPO/.claude/commands/
cp claude-commands/sdd-test.md           YOUR_REPO/.claude/commands/
cp claude-commands/sdd-release.md        YOUR_REPO/.claude/commands/
cp claude-commands/sdd-research.md       YOUR_REPO/.claude/commands/
cp claude-commands/sdd-init.md           YOUR_REPO/.claude/commands/
cp claude-commands/sdd-clarify.md        YOUR_REPO/.claude/commands/
cp claude-commands/sdd-requirements.md   YOUR_REPO/.claude/commands/
```

### Step 3 — Copy skills to `.specky/skills/`

```bash
mkdir -p YOUR_REPO/.specky/skills/{implementer,test-verifier,release-engineer,research-analyst}

cp specky-skills/implementer/SKILL.md       YOUR_REPO/.specky/skills/implementer/
cp specky-skills/test-verifier/SKILL.md      YOUR_REPO/.specky/skills/test-verifier/
cp specky-skills/release-engineer/SKILL.md   YOUR_REPO/.specky/skills/release-engineer/
cp specky-skills/research-analyst/SKILL.md   YOUR_REPO/.specky/skills/research-analyst/
```

### Step 4 — Verify

After installation, your repo should have:

```
.github/agents/
├── spec-engineer.agent.md        ← existing
├── design-architect.agent.md     ← existing
├── task-planner.agent.md         ← existing
├── spec-reviewer.agent.md        ← existing
├── requirements-engineer.agent.md ← existing
├── implementer.agent.md          ← NEW
├── test-verifier.agent.md        ← NEW
├── release-engineer.agent.md     ← NEW
└── research-analyst.agent.md     ← NEW

.claude/commands/
├── sdd-spec.md                   ← existing
├── sdd-design.md                 ← existing
├── sdd-tasks.md                  ← existing
├── sdd-analyze.md                ← existing
├── sdd-bugfix.md                 ← existing
├── sdd-requirements.md           ← NEW
├── sdd-init.md                   ← NEW
├── sdd-research.md               ← NEW
├── sdd-clarify.md                ← NEW
├── sdd-implement.md              ← NEW
├── sdd-test.md                   ← NEW
└── sdd-release.md                ← NEW

.specky/skills/
├── requirements-engineer/SKILL.md ← existing
├── sdd-spec-engineer/SKILL.md     ← existing
├── implementer/SKILL.md           ← NEW
├── test-verifier/SKILL.md         ← NEW
├── release-engineer/SKILL.md      ← NEW
└── research-analyst/SKILL.md      ← NEW
```

---

## Complete Pipeline Command Map

After installation, every phase of the 10-phase SDD pipeline has a dedicated command:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    THE COMPLETE SDD PIPELINE                        │
│                 Every phase → agent → command → tools                │
└─────────────────────────────────────────────────────────────────────┘

PRE-PIPELINE
  /sdd:requirements  →  requirements-engineer  →  FRD + NFRD
  │                      Model: Opus + thinking
  │                      Tools: (pre-pipeline, no Specky tools)
  ▼
PHASE 0 — INIT
  /sdd:init          →  (direct tool call)      →  CONSTITUTION.md
  │                      Model: Haiku 4.5
  │                      Tools: sdd_init
  ▼
PHASE 1 — RESEARCH                                              🆕
  /sdd:research      →  research-analyst        →  RESEARCH.md
  │                      Model: Sonnet 4.6
  │                      Tools: sdd_research, sdd_scan_codebase,
  │                             sdd_check_ecosystem, sdd_import_*
  ▼
PHASE 2 — CLARIFY                                               🆕
  /sdd:clarify       →  spec-reviewer           →  SPECIFICATION.md (updated)
  │                      Model: Opus + thinking
  │                      Tools: sdd_clarify, sdd_validate_ears
  │  ↕ (loop with Phase 3)
  ▼
PHASE 3 — SPECIFY
  /sdd:spec          →  spec-engineer           →  SPECIFICATION.md
  │                      Model: Opus + thinking
  │                      Tools: sdd_write_spec, sdd_turnkey_spec
  │                      Hooks: spec-quality.sh, auto-checkpoint.sh
  ▼
PHASE 4 — DESIGN
  /sdd:design        →  design-architect        →  DESIGN.md
  │                      Model: Opus + thinking
  │                      Tools: sdd_write_design, sdd_generate_*_diagrams
  │                      Hooks: auto-checkpoint.sh
  ▼
PHASE 5 — TASKS
  /sdd:tasks         →  task-planner            →  TASKS.md
  │                      Model: Sonnet 4.6
  │                      Tools: sdd_write_tasks, sdd_export_work_items
  │                      Hooks: task-tracer.sh, auto-checkpoint.sh
  ▼
PHASE 6 — IMPLEMENT                                             🆕
  /sdd:implement     →  implementer             →  CHECKLIST.md + scaffolding
  │                      Model: Sonnet 4.6, thinking: false
  │                      Tools: sdd_implement, sdd_checklist,
  │                             sdd_generate_tests, sdd_generate_pbt,
  │                             sdd_generate_iac, sdd_generate_dockerfile
  │                      Hooks: spec-sync.sh (during coding)
  ▼
PHASE 7 — VERIFY                                                🆕
  /sdd:test          →  test-verifier           →  VERIFICATION.md
  │                      Model: Sonnet 4.6
  │                      Tools: sdd_verify_tests, sdd_verify_tasks,
  │                             sdd_check_sync
  │                      Hooks: spec-sync.sh
  ▼
PHASE 8 — REVIEW
  /sdd:analyze       →  spec-reviewer           →  ANALYSIS.md + gate decision
  │                      Model: Opus + thinking
  │                      Tools: sdd_run_analysis, sdd_compliance_check,
  │                             sdd_cross_analyze, sdd_metrics, sdd_detect_drift
  │                      Hooks: cognitive-debt-alert.sh, drift-monitor.sh
  ▼
PHASE 9 — RELEASE                                               🆕
  /sdd:release       →  release-engineer        →  PR + docs
                         Model: Haiku 4.5
                         Tools: sdd_create_pr, sdd_generate_all_docs,
                                sdd_export_work_items
                         Hooks: security-scan.sh (BLOCKING),
                                release-gate.sh (BLOCKING)
```

---

## Model Routing Summary

| Phase | Agent | Model | Thinking | Cost Multiplier |
|-------|-------|-------|----------|-----------------|
| Pre-0 | requirements-engineer | Opus 4.6 | Yes | 3x |
| 0 | (direct) | Haiku 4.5 | No | 0.33x |
| 1 | research-analyst | Sonnet 4.6 | No | 1x |
| 2 | spec-reviewer | Opus 4.6 | Yes | 3x |
| 3 | spec-engineer | Opus 4.6 | Yes | 3x |
| 4 | design-architect | Opus 4.6 | Yes | 3x |
| 5 | task-planner | Sonnet 4.6 | No | 1x |
| 6 | implementer | Sonnet 4.6 | **No** | 1x |
| 7 | test-verifier | Sonnet 4.6 | No | 1x |
| 8 | spec-reviewer | Opus 4.6 | Yes | 3x |
| 9 | release-engineer | Haiku 4.5 | No | 0.33x |

**Cost distribution:** Reasoning budget concentrated on Phases 2-4 (clarify, specify, design) where errors cascade. Implementation and release phases use cheaper models because they have executable feedback loops.

---

## Handoff Chain

```
requirements-engineer  ──FRD+NFRD──►  sdd_init
                                         │
                                    CONSTITUTION.md
                                         │
research-analyst  ────RESEARCH.md──►  spec-engineer ◄──► spec-reviewer
                                         │                  (clarify loop)
                                    SPECIFICATION.md
                                         │
                                    design-architect
                                         │
                                      DESIGN.md
                                         │
                                     task-planner
                                         │
                                      TASKS.md
                                         │
                                     implementer
                                         │
                                  Code + CHECKLIST.md
                                         │
                                    test-verifier
                                         │
                                   VERIFICATION.md
                                         │
                                    spec-reviewer (review gate)
                                         │
                                     ANALYSIS.md
                                         │
                                   release-engineer
                                         │
                                    PR + docs → DONE ✅
```

Every arrow is a file handoff. No API calls between agents. File-based communication per ADR-001.

---

## Usage Examples

### Full pipeline from scratch

```
/sdd:requirements "Build a task management API with JWT auth and RBAC"
  → FRD + NFRD created
/sdd:init task-management-api
  → CONSTITUTION.md created, Phase 0 complete
/sdd:research 001
  → RESEARCH.md with tech stack, ecosystem recommendations
/sdd:spec 001
  → SPECIFICATION.md with EARS requirements
/sdd:clarify 001
  → Disambiguation questions resolved
/sdd:design 001
  → DESIGN.md with C4 diagrams, ADRs
/sdd:tasks 001
  → TASKS.md with sequenced implementation plan
/sdd:implement 001
  → Implementation plan + checklists + test stubs generated
  → Developer writes code...
/sdd:test 001
  → VERIFICATION.md with traceability report
/sdd:analyze 001
  → ANALYSIS.md + quality gate decision
/sdd:release 001
  → PR created + docs generated → DONE
```

### Quick brownfield feature

```
/sdd:init add-notifications
/sdd:research 002           ← sdd_scan_codebase detects existing stack
/sdd:spec 002
/sdd:design 002
/sdd:tasks 002
/sdd:implement 002
/sdd:test 002
/sdd:analyze 002
/sdd:release 002
```

### Using Copilot agents instead

```
@research-analyst Analyze the existing codebase and prepare for feature 003
@spec-engineer Write EARS requirements for feature 003
@design-architect Create architecture for feature 003
@task-planner Break feature 003 into implementation tasks
@implementer Prepare implementation scaffold for feature 003
@test-verifier Verify test coverage for feature 003
@spec-reviewer Run quality gate for feature 003
@release-engineer Prepare release for feature 003
```
