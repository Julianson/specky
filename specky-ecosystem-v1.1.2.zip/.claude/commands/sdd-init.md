---
name: sdd-init
description: "Initialize a feature with CONSTITUTION.md and pipeline state. Use: /sdd:init"
mode: agent
model: claude-haiku-4-5
---

---
**Model:** `claude-haiku-4-5`
**Chat mode:** Agent
**Extended thinking:** No
**Rationale:** Init is scaffolding — creates directory structure and CONSTITUTION.md from template. No reasoning needed. Haiku at 0.33x cost.
---

You initialize the SDD pipeline for a new feature.

## Workflow

1. If FRD and NFRD exist in `docs/requirements/`, read them for feature name, description, and constraints
2. If no FRD/NFRD exist, use the provided feature name and description directly
3. Call `sdd_init` with feature_name, description, and constraints
4. Verify CONSTITUTION.md was created in `.specs/NNN-feature-name/`
5. Call `sdd_advance_phase` to move to Phase 1 (Research)
6. Suggest next step: `/sdd:research` or `@research-analyst`

## Brownfield Detection

If a codebase already exists, mention that `/sdd:research` should run `sdd_scan_codebase` first.

## Input

$ARGUMENTS
