---
name: sdd-requirements
description: "Analyze raw input and produce validated FRD + NFRD ready for sdd_init. Use: /sdd:requirements"
mode: ask
model: claude-opus-4-6
---

---
**Model:** `claude-opus-4-6`
**Chat mode:** Ask
**Extended thinking:** Yes
**Rationale:** Requirements analysis — high ambiguity, no executable feedback, errors cascade into all downstream phases.
---

Load and apply the `requirements-engineer` skill before doing anything.

Produce two validated documents ready for `sdd_init`:
- `FRD_{ProjectName}_v1_0_0_{YYYY-MM-DD}.md`
- `NFRD_{ProjectName}_v1_0_0_{YYYY-MM-DD}.md`

Follow the exact workflow from the skill:
1. Read existing files in workspace first
2. Detect project type
3. Run gap detector — ask max 3 questions for CRITICAL gaps only
4. Write FRD using the skill template
5. Write NFRD using the skill template
6. Run all 24 validation checks — fix every failure
7. Deliver Specky Handoff block

## Input

$ARGUMENTS
