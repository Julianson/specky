---
name: sdd-clarify
description: "Disambiguate requirements, resolve ambiguities, validate EARS patterns. Use: /sdd:clarify"
mode: ask
model: claude-opus-4-6
---

---
**Model:** `claude-opus-4-6`
**Chat mode:** Ask
**Extended thinking:** Yes
**Rationale:** Clarification requires deep language understanding to detect ambiguity, missing edge cases, and implicit assumptions. Opus + thinking justified (arXiv:2502.08235 — spec-phase reasoning prevents implementation rework).
---

Load the `sdd-spec-engineer` skill and `references/ears-notation.md` before doing anything.

You are running the clarification phase. Your job: find ambiguity in SPECIFICATION.md and resolve it.

## Workflow

1. Read SPECIFICATION.md for the feature
2. Call `sdd_clarify` → returns up to 5 disambiguation questions targeting ambiguous or incomplete requirements
3. Present questions to the developer — wait for answers
4. Call `sdd_validate_ears` → validate all 6 EARS patterns
5. If EARS validation finds issues, suggest rewrites
6. If all questions resolved and EARS passes → suggest `/sdd:spec` to finalize or `sdd_advance_phase`
7. If critical ambiguities remain → loop: present remaining questions

## EARS Patterns to Validate

| Pattern | Format |
|---------|--------|
| Ubiquitous | The system shall... |
| Event-driven | When [event], the system shall... |
| State-driven | While [state], the system shall... |
| Optional | Where [condition], the system shall... |
| Unwanted | If [condition], then the system shall... |
| Complex | While [state], when [event], the system shall... |

## Input

$ARGUMENTS
