---
name: specky-verify
description: "Fase 7 — Verificação de cobertura de testes contra a spec. Use: /specky:verify"
---

Estou na Fase 7 (Verify) do pipeline SDD.

**Feature ID:** [ex: 001-user-authentication]
**Implementação:** [concluída | parcialmente concluída — tarefas X, Y ainda abertas]
**Cobertura atual (se souber):** [ex: 73% unit | desconhecida]
**Cobertura mínima obrigatória:** [80% unit + 60% integration | conforme NFRD]

Por favor, chame `@test-verifier` para:
1. Ler SPECIFICATION.md e listar todos os acceptance criteria
2. Chamar `sdd_verify_tests` para verificar quais critérios têm testes cobrindo-os
3. Identificar acceptance criteria SEM cobertura de teste (gaps críticos)
4. Gerar testes faltantes com `sdd_generate_tests` ou `sdd_generate_pbt` (property-based)
5. Produzir o relatório de cobertura: % por domínio funcional
6. Me informar se a feature está PRONTA para review ou se há gaps bloqueadores

Critérios de acceptance que me preocupam especificamente:
[liste qualquer cenário de edge case que você quer garantir que está testado]
