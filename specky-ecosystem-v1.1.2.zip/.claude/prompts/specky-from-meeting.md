---
name: specky-from-meeting
description: "Transforma transcript de reunião de descoberta em requisitos SDD. Use: /specky:from-meeting"
---

Tenho o transcript de uma reunião de discovery/refinamento e quero transformá-lo em requisitos.

**Arquivo do transcript:** [caminho do arquivo .vtt, .srt, ou .txt — ex: transcripts/discovery-2026-04-13.vtt]
**Tipo de reunião:** [discovery inicial | refinamento | revisão de spec | reunião de stake holders]
**Participantes-chave:** [ex: Paula (PO), João (Tech Lead), Maria (Dev) — quem tem poder de decisão?]
**Feature relacionada:** [Feature ID se já existir, ou "nova feature — iniciar pipeline"]
**Decisões que eu TENHO CERTEZA que foram tomadas:** [liste qualquer decisão que você lembra, para o Specky validar]

Por favor, chame `@research-analyst` para:
1. Chamar `sdd_import_transcript` no arquivo fornecido
2. Identificar no transcript: decisões tomadas, requisitos mencionados, restrições declaradas, perguntas em aberto
3. Classificar cada item por: DECISÃO FIRME | PREFERÊNCIA | DÚVIDA ABERTA | FORA DE ESCOPO
4. Cruzar as decisões que eu listei acima com o que foi realmente dito no transcript (validar memória)
5. Produzir RESEARCH.md com seção específica "Decisões da Reunião de [data]"
6. Listar os itens que ficaram em aberto e precisam de follow-up antes de especificar

Se encontrar contradições entre o que participantes diferentes disseram, me aponte explicitamente.
