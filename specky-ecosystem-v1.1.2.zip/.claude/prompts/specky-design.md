---
name: specky-design
description: "Fase 4 — Arquitetura técnica e design de sistema. Use: /specky:design"
---

Estou na Fase 4 (Design) do pipeline SDD.

**Feature ID:** [ex: 001-user-authentication]
**SPECIFICATION.md:** [aprovada e validada | ainda em revisão]
**Restrições arquiteturais obrigatórias:** [ex: deve usar o banco PostgreSQL existente | deve ser serverless | deploy em Azure AKS]
**Padrões arquiteturais preferidos:** [ex: hexagonal architecture | clean architecture | sem preferência]

Por favor, chame `@design-architect` para:
1. Ler SPECIFICATION.md e transformar cada grupo de REQs em componentes de design
2. Chamar `sdd_write_design` para produzir DESIGN.md com:
   - Diagrama de componentes (em Mermaid)
   - Diagrama de sequência para os fluxos principais
   - Decisões de dados: schemas, índices, migrations
   - Decisões de integração: contratos de API, eventos, webhooks
   - ADRs (Architecture Decision Records) para cada escolha não-óbvia
3. Verificar rastreabilidade: cada componente referencia os REQ-IDs que atende
4. Identificar riscos técnicos e documentar estratégias de mitigação

Contexto adicional:
[qualquer informação sobre a infra existente, times, dependências externas]
