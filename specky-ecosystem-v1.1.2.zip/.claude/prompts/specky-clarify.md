---
name: specky-clarify
description: "Fase 2 — Resolução de ambiguidades nos requisitos. Use: /specky:clarify"
---

Estou na Fase 2 (Clarify) do pipeline SDD.

**Feature ID:** [ex: 001-user-authentication]
**SPECIFICATION.md existe:** [sim — já foi criado pelo spec-engineer | não — precisa ser criado primeiro]
**Prazo para resolver ambiguidades:** [ex: preciso finalizar hoje | sem urgência]

Por favor, chame `@sdd-clarify` para:
1. Ler CONSTITUTION.md + RESEARCH.md + SPECIFICATION.md
2. Rodar `sdd_clarify` para detectar: ambiguidades, contradições, violações EARS, gaps de cobertura
3. Me apresentar os itens CRÍTICOS primeiro (no máximo 5 por vez)
4. Aguardar minhas respostas antes de reescrever qualquer requisito
5. Validar compliance EARS com `sdd_validate_ears` ao final
6. Produzir o CLARIFICATION-LOG.md com todas as decisões registradas

Itens que já sei que precisam de atenção:
[liste aqui qualquer requisito específico que te preocupa, ou escreva "nenhum"]
