---
name: specky-specify
description: "Fase 3 — Escrita da especificação completa em EARS notation. Use: /specky:specify"
---

Estou na Fase 3 (Specify) do pipeline SDD.

**Feature ID:** [ex: 001-user-authentication]
**RESEARCH.md status:** [completo | incompleto — faltam: X, Y]
**Clarifications pendentes:** [nenhuma | resolvi todas | ainda tenho dúvidas sobre: X]

Por favor, chame `@spec-engineer` para:
1. Ler CONSTITUTION.md + RESEARCH.md + CLARIFICATION-LOG.md (se existir)
2. Chamar `sdd_write_spec` para escrever a SPECIFICATION.md completa em EARS notation
3. Garantir que cada requisito tenha: REQ-ID único, padrão EARS, acceptance criteria testáveis
4. Cobrir os 5 padrões EARS: Ubiquitous, Event-driven, State-driven, Optional, Unwanted behavior
5. Rodar `sdd_validate_ears` para validação
6. Apresentar o resumo: total de REQs por domínio, gaps identificados

Domínios que DEVEM ser cobertos:
[liste os domínios funcionais — ex: Autenticação, Autorização, Notificações, Auditoria]

Domínios que estão fora de escopo (conforme CONSTITUTION.md):
[liste ou escreva "ver CONSTITUTION.md"]
