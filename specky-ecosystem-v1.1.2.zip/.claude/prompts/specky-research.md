---
name: specky-research
description: "Fase 1 — Pesquisa e descoberta. Use: /specky:research"
---

Estou na Fase 1 (Research) do pipeline SDD.

**Feature ID:** [ex: 001-user-authentication]
**O que já existe:** [CONSTITUTION.md criado? sim/não | FRD/NFRD disponíveis? sim/não]
**Documentos externos para importar:** [lista de arquivos ou "nenhum"]
**Perguntas técnicas abertas:** [ex: "Qual biblioteca de JWT usar com Node.js?", "Como integrar com o Active Directory?", ou "nenhuma ainda"]

Por favor, chame `@research-analyst` para:
1. Ler o CONSTITUTION.md da feature
2. Escanear o codebase existente (se brownfield)
3. Importar os documentos listados acima
4. Rodar `sdd_discover` e me apresentar as 7 perguntas de descoberta
5. Produzir o RESEARCH.md ao final

Quando o RESEARCH.md estiver pronto, me avise para seguirmos para a Fase 2 (Clarify) ou Fase 3 (Specify).
