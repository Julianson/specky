---
name: specky-brownfield
description: "Inicia pipeline SDD para adicionar uma feature a um sistema existente. Use: /specky:brownfield"
---

Quero usar o Specky SDD para especificar uma nova feature em um sistema já existente.

**Feature:** [NOME DA FEATURE — ex: autenticação OAuth2, exportação PDF, webhook de pagamento]
**Sistema existente:** [breve descrição do sistema atual]
**Por que agora:** [motivação — ex: demanda de cliente, requisito de compliance, débito técnico]
**Restrições conhecidas:** [ex: não pode quebrar a API v1, precisa rodar no mesmo banco]

Por favor:
1. Rode `sdd_scan_codebase` para detectar a stack atual e padrões existentes
2. Chame `@requirements-engineer` para extrair FRD/NFRD considerando as restrições do sistema legado
3. Chame `@sdd-init` com `project_type: brownfield` para inicializar o pipeline
4. Me informe quais integrações existentes foram detectadas e o que pode ser reaproveitado
