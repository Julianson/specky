---
name: specky-tasks
description: "Fase 5 — Quebrar design em tarefas de implementação sequenciadas. Use: /specky:tasks"
---

Estou na Fase 5 (Tasks) do pipeline SDD.

**Feature ID:** [ex: 001-user-authentication]
**DESIGN.md:** [aprovado | ainda em revisão]
**Tamanho do time:** [solo | 2-3 devs | time maior]
**Sprint length:** [1 semana | 2 semanas | sem sprints definidos]
**Paralelização desejada:** [máxima — marcar tarefas [P] para paralelas | sequencial — mais simples]

Por favor, chame `@task-planner` para:
1. Ler DESIGN.md e decompor em tarefas atômicas de implementação
2. Chamar `sdd_write_tasks` para produzir TASKS.md com:
   - Sequência obrigatória (dependências entre tarefas)
   - Tarefas marcadas com [P] onde paralelização é segura
   - Estimativa de esforço por tarefa
   - Pre-implementation gate: quais tarefas precisam de aprovação antes de começar
   - Rastreabilidade: cada tarefa mapeia para REQ-IDs e componentes do DESIGN.md
3. O hook `task-tracer.sh` vai validar automaticamente que nenhum REQ ficou sem tarefa
4. Me apresente o critical path: quais tarefas determinam o prazo total

Prioridade de entrega (P0 = MVP, P1 = nice-to-have):
[descreva o que é essencial para o primeiro deploy]
