---
name: specky-resolve-conflict
description: "Resolve conflito entre dois requisitos contraditórios. Use: /specky:resolve-conflict"
---

Encontrei um conflito entre dois requisitos e preciso resolvê-lo antes de continuar.

**Feature ID:** [ex: 001-user-authentication]
**REQ em conflito A:** [ID + texto completo — ex: REQ-001-AUTH-007: "Sessões expiram em 30 minutos"]
**REQ em conflito B:** [ID + texto completo — ex: REQ-001-AUTH-012: "Usuários permanecem logados por 7 dias"]
**Contexto do conflito:** [quando foi descoberto? qual comportamento causou o problema?]
**Minha hipótese:** [o que você acha que deveria ser o comportamento correto, se tiver opinião]

Por favor, chame `@sdd-clarify` para:
1. Analisar o contexto de ambos os requisitos: de onde vêm, quem os escreveu, qual user story atendem
2. Verificar se os dois REQs podem ser verdadeiros simultaneamente (ex: diferentes user roles, diferentes contextos)
3. Apresentar 3 opções de resolução com trade-offs de cada uma
4. Aguardar minha decisão
5. Reescrever os REQs afetados em EARS notation após minha escolha
6. Registrar a decisão no CLARIFICATION-LOG.md com: data, decisão tomada, justificativa
7. Verificar se outros REQs na spec são afetados pela resolução escolhida

Não tome a decisão por mim — apresente as opções e aguarde minha confirmação.
