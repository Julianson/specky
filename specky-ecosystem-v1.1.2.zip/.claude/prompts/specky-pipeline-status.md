---
name: specky-pipeline-status
description: "Mostra o status atual do pipeline SDD e qual é o próximo passo. Use: /specky:status"
---

Quero entender onde estou no pipeline SDD e o que precisa acontecer agora.

**Feature ID:** [ex: 001-user-authentication — ou "todas as features ativas"]

Por favor:
1. Leia `.specs/[feature]/pipeline.state.yml` para identificar a fase atual
2. Liste todos os artefatos e seus status:
   ```
   CONSTITUTION.md    [✅ existe | ❌ falta | ⚠️ desatualizado]
   RESEARCH.md        [✅ | ❌ | ⚠️]
   SPECIFICATION.md   [✅ | ❌ | ⚠️]
   CLARIFICATION-LOG  [✅ | ❌ | não necessário]
   DESIGN.md          [✅ | ❌ | ⚠️]
   TASKS.md           [✅ | ❌ | ⚠️]
   ```
3. Mostre a última vez que cada artefato foi modificado (via git log)
4. Rode `sdd_context_status` para obter o status completo da sessão atual
5. Me diga claramente: **qual é o próximo passo obrigatório** para avançar no pipeline
6. Se houver múltiplas features ativas, mostre o status de cada uma em formato de tabela

Se o pipeline estiver travado (ex: uma fase não foi concluída há mais de 7 dias), me alerte e sugira: retomar de onde parou | reiniciar a fase | escalar para revisão.
