---
name: specky-debug-hook
description: "Diagnostica por que um hook está bloqueando ou falhando. Use: /specky:debug-hook"
---

Um hook do Specky está bloqueando meu workflow ou falhando com erro.

**Hook problemático:** [ex: security-scan.sh | release-gate.sh | spec-quality.sh]
**Mensagem de erro recebida:** [cole a mensagem de erro completa]
**Quando acontece:** [ex: ao tentar criar PR | ao salvar a spec | ao final da sessão]
**Plataforma:** [Claude Code | VS Code Copilot | GitHub Actions CI]

Por favor, me ajude a diagnosticar:

1. **Se é `security-scan.sh` (BLOCKING):**
   - Execute `bash .specky/hooks/security-scan.sh` diretamente e me mostre a saída completa
   - Liste os arquivos em `.specs/` que contém os padrões suspeitos detectados
   - Me diga: é um falso positivo (ex: string "api_key" em comentário de exemplo) ou um segredo real que precisa ser removido?

2. **Se é `release-gate.sh` (BLOCKING):**
   - Execute `bash .specky/hooks/release-gate.sh` e me mostre o checklist de falhas
   - Quais artefatos estão faltando? (CONSTITUTION.md, SPECIFICATION.md, DESIGN.md, TASKS.md)
   - A cobertura de testes está abaixo do mínimo?
   - Há itens CRÍTICOS abertos no CLARIFICATION-LOG.md?

3. **Se é um hook Advisory (exit 0) mas aparece erro:**
   - Verifique se o script tem permissão de execução: `ls -la .specky/hooks/`
   - Execute `bash -x .specky/hooks/[nome].sh` para trace detalhado
   - Verifique se o diretório `.specky/metrics/` existe e tem permissão de escrita

4. **Se o hook não está disparando:**
   - Verifique JSON válido: `cat .claude/settings.json | python3 -m json.tool`
   - Confirme que o matcher do hook corresponde ao nome da ferramenta usada
   - Para VS Code: confirme que recarregou a janela após editar `.vscode/settings.json`

Me mostre o resultado de cada verificação antes de propor uma correção.
