---
name: specky-api
description: "Inicia pipeline SDD para design e documentação de API. Use: /specky:api"
---

Quero usar o Specky SDD para projetar uma API.

**Nome da API:** [ex: Payments API v2, User Management API]
**Consumidores:** [ex: app mobile iOS/Android, parceiros externos, front-end React interno]
**Protocolo:** [REST / GraphQL / gRPC / WebSocket / híbrido]
**Autenticação:** [OAuth2 / API Key / JWT / SAML / a definir]
**Versioning strategy:** [path versioning /v1/ | header versioning | nenhuma ainda]
**SLA de disponibilidade:** [ex: 99.9%, 99.99%]

Por favor:
1. Extraia os contratos de API como requisitos funcionais (cada endpoint = REQ com EARS notation)
2. Os NFRs devem cobrir: rate limiting, throttling, autenticação, formato de erro padrão, pagination
3. No DESIGN.md, gere o OpenAPI 3.1 schema inicial como parte do design
4. Chame `@sdd-init project_type: api` para inicializar
