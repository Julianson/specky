---
name: specky-reset-phase
description: "Retorna o pipeline a uma fase anterior para retrabalho. Use: /specky:reset-phase"
---

Preciso voltar o pipeline para uma fase anterior porque algo mudou significativamente.

**Feature ID:** [ex: 001-user-authentication]
**Fase atual:** [ex: Fase 6 — Implement]
**Fase de destino (retornar para):** [ex: Fase 3 — Specify]
**Motivo do retorno:**
- [ ] Requisitos mudaram (stakeholder mudou de opinião)
- [ ] Design arquitetural inviável (descoberta técnica)
- [ ] Spec incompleta (gap descoberto na implementação)
- [ ] Compliance novo (requisito legal surgiu)
- [ ] Outro: [descreva]

**O que NÃO deve ser perdido:** [ex: o RESEARCH.md está bom e não precisa refazer | as decisões do CLARIFICATION-LOG devem ser mantidas]

Por favor:
1. Crie um snapshot do estado atual antes de qualquer mudança: `git tag specky-snapshot-phase[N]-[YYYY-MM-DD]`
2. Atualize `pipeline.state.yml` para a fase de destino
3. Documente no Change Log dos artefatos afetados: data, motivo, quem decidiu o retorno
4. Me diga quais artefatos precisam ser reescritos vs. quais podem ser aproveitados
5. Se artefatos das fases posteriores ficarem desatualizados (ex: DESIGN.md fica stale após mudar SPECIFICATION.md), sinalize-os como `status: stale` no pipeline.state.yml
6. Me apresente o plano de retomada: o que fazer primeiro para chegar de volta à fase atual com qualidade

⚠️ Não delete nenhum arquivo sem minha confirmação explícita.
