---
name: specky-implement
description: "Fase 6 — Execução da implementação a partir do TASKS.md. Use: /specky:implement"
---

Estou na Fase 6 (Implement) do pipeline SDD.

**Feature ID:** [ex: 001-user-authentication]
**TASKS.md:** [aprovado e pronto | ainda precisa de revisão]
**Tarefa específica a implementar:** [nome da tarefa do TASKS.md, ou "próxima tarefa pendente"]
**Contexto de ambiente:** [local | CI/CD | Codespaces | devcontainer]

Por favor, chame `@implementer` para:
1. Ler TASKS.md e identificar a próxima tarefa (ou a tarefa especificada)
2. Verificar pré-condições: dependências concluídas? ambiente configurado?
3. Gerar o plano de implementação detalhado com `sdd_implement`
4. Criar stubs de teste com `sdd_generate_tests` antes de escrever o código de produção
5. Para infra: gerar IaC com `sdd_generate_iac` se necessário
6. Executar a tarefa e marcar como concluída no TASKS.md
7. Chamar o hook `auto-checkpoint.sh` para criar um checkpoint git

⚠️ IMPORTANTE: Esta fase usa Sonnet 4.6 SEM extended thinking (arXiv:2502.08235).
O código é escrito com feedback executável, não com raciocínio prolongado.

Contexto adicional:
[variáveis de ambiente necessárias, credenciais de teste, serviços externos mockados]
