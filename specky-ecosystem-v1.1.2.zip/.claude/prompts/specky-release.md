---
name: specky-release
description: "Fase 9 — Checklist de release e criação do PR. Use: /specky:release"
---

Estou na Fase 9 (Release) do pipeline SDD e quero criar o PR final.

**Feature ID:** [ex: 001-user-authentication]
**Branch:** [ex: feature/001-user-authentication]
**Target branch:** [main | develop | staging]
**Tipo de deploy:** [blue-green | canary | rolling | direto]
**Observability configurada:** [sim — dashboards X, Y | não — precisa configurar]

Por favor, chame `@release-engineer` para:
1. Executar `release-gate.sh` (BLOCKING) — verifica se todos os artefatos existem e passam
2. Executar `security-scan.sh` (BLOCKING) — verifica se não há segredos nos specs
3. Chamar `sdd_create_pr` apenas se AMBOS os gates passarem
4. O PR deve incluir: summary dos REQs implementados, link para SPECIFICATION.md, checklist de rollback
5. Gerar CHANGELOG.md entry para esta feature

Se algum gate BLOQUEAR, me diga exatamente o que está faltando antes de criar o PR.

Notas adicionais para o PR:
[qualquer contexto para os reviewers, breaking changes, migration steps necessários]
