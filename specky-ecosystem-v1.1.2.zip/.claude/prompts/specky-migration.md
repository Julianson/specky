---
name: specky-migration
description: "Inicia pipeline SDD para migração de sistema legado ou modernização de stack. Use: /specky:migration"
---

Quero usar o Specky SDD para planejar uma migração / modernização.

**Sistema de origem:** [ex: monolito PHP 5.6 + MySQL, microserviço Node.js 14]
**Sistema de destino:** [ex: FastAPI + PostgreSQL + Kubernetes, Next.js 14]
**Tipo de migração:** [lift-and-shift | rewrite | strangler fig | blue-green]
**Dados críticos:** [ex: 2M usuários, histórico de transações dos últimos 5 anos]
**Zero-downtime obrigatório:** [sim / não / janela de manutenção aceitável de N horas]

Por favor:
1. Rode `sdd_scan_codebase` para mapear o sistema de origem completamente
2. Chame `@requirements-engineer` com foco em: quais comportamentos DEVEM ser preservados, quais podem ser descartados e quais devem ser modernizados
3. Inicialize com `@sdd-init project_type: migration`
4. No CONSTITUTION.md, liste explicitamente o que está fora de escopo desta migração
