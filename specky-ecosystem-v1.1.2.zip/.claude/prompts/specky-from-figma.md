---
name: specky-from-figma
description: "Extrai requisitos diretamente de um design Figma e inicia o pipeline. Use: /specky:from-figma"
---

Tenho um design no Figma e quero transformá-lo em uma especificação SDD completa.

**URL do Figma:** [cole a URL do arquivo ou frame específico]
**Feature ID:** [ex: 003-checkout-flow — ou deixe em branco para criar novo]
**Contexto do design:** [o que este design representa? ex: "fluxo de checkout com 4 telas"]
**O que vem do design vs. o que ainda precisa ser descoberto:**
- Do Figma vem: [ex: fluxos de tela, estados de UI, mensagens de erro]
- Ainda precisa definir: [ex: regras de negócio, integrações, casos de edge]

Por favor:
1. Chame `sdd_figma_to_spec` com a URL fornecida para extrair requisitos do design
2. O Figma geralmente cobre os "happy paths" — identifique e liste os cenários de erro NÃO cobertos pelo design
3. Gere perguntas de descoberta específicas para os gaps encontrados
4. Complemente com EARS notation para os fluxos do design E os edge cases não mapeados
5. Produza SPECIFICATION.md com rastreabilidade: cada REQ aponta para o frame/componente Figma de origem

Ao final, me mostre: quantos REQs vieram do Figma, quantos foram adicionados por inferência, e quais ainda precisam de input do time.
