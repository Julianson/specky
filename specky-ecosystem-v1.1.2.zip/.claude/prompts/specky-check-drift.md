---
name: specky-check-drift
description: "Detecta divergência entre código implementado e a especificação. Use: /specky:check-drift"
---

Quero verificar se a implementação atual ainda está alinhada com a especificação.

**Feature ID:** [ex: 001-user-authentication]
**Motivo da verificação:** [ex: passaram 2 semanas desde a spec | houve mudanças de escopo mid-sprint | PR review identificou comportamento diferente da spec]
**Arquivos de código que mudaram:** [lista de arquivos ou "verificar tudo"]

Por favor:
1. Execute `drift-monitor.sh` para comparar o comportamento implementado contra SPECIFICATION.md
2. Chame `sdd_cross_analyze` para análise cruzada entre spec e código
3. Me apresente o relatório de drift em 3 categorias:
   - 🟢 **Conforme:** implementação = spec
   - 🟡 **Divergência menor:** implementação difere mas intenção é equivalente
   - 🔴 **Drift crítico:** implementação contradiz ou ignora um REQ
4. Para cada drift crítico: me mostre o REQ original, o comportamento atual, e as opções:
   - Corrigir o código para alinhar com a spec
   - Atualizar a spec para refletir a nova realidade (com justificativa documentada)
5. Atualize pipeline.state.yml com o resultado da análise

Contexto adicional (mudanças que eu sei que aconteceram):
[descreva qualquer decisão de implementação que divergiu conscientemente da spec]
