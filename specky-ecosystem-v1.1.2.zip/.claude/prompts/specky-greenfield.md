---
name: specky-greenfield
description: "Inicia pipeline SDD para um projeto novo do zero. Use: /specky:greenfield"
---

Quero iniciar um projeto greenfield com o Specky SDD.

**Projeto:** [NOME DO PROJETO]
**Descrição:** [O que o sistema vai fazer em 1-2 frases]
**Stack prevista:** [ex: Node.js + PostgreSQL + React | Python + FastAPI | ainda não definida]
**Prazo / milestone:** [ex: MVP em 8 semanas | sem prazo definido]
**Compliance:** [ex: GDPR | HIPAA | SOC 2 | nenhum]

Por favor:
1. Chame `@requirements-engineer` para extrair FRD e NFRD a partir dessas informações
2. Em seguida, `@sdd-init` para inicializar o pipeline e criar o CONSTITUTION.md
3. Me mostre o número da feature (NNN) gerado e o caminho `.specs/NNN-[feature]/`
