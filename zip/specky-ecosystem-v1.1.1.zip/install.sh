#!/bin/bash
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(pwd)"

echo -e "${BLUE}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     Specky SDD Ecosystem — One-Click Installer          ║${NC}"
echo -e "${BLUE}║   v3.2.0 · 67 files · dual-target · 3-layer hooks      ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════╝${NC}"
echo -e "Project: ${GREEN}$REPO_DIR${NC}"
echo ""

# ─── [1/10] MCP Server ──────────────────────────────────────────────────────
echo -e "${YELLOW}[1/10] Installing Specky MCP Server...${NC}"
if ! command -v node &>/dev/null; then
  echo -e "  ${RED}✗${NC} Node.js required: https://nodejs.org/"; exit 1
fi
npm install -g specky-sdd 2>/dev/null && echo -e "  ${GREEN}✓${NC} specky-sdd@3.2.0 installed" || echo -e "  ${YELLOW}ℹ${NC} Will use npx on first run"

# ─── [2/10] VS Code MCP config ──────────────────────────────────────────────
echo -e "${YELLOW}[2/10] Configuring VS Code MCP...${NC}"
mkdir -p "$REPO_DIR/.vscode"
if [ ! -f "$REPO_DIR/.vscode/mcp.json" ]; then
  cp "$SCRIPT_DIR/.vscode/mcp.json" "$REPO_DIR/.vscode/mcp.json"
  echo -e "  ${GREEN}✓${NC} VS Code:     .vscode/mcp.json created"
else
  echo -e "  ${GREEN}✓${NC} VS Code:     .vscode/mcp.json already exists"
fi

# ─── [3/10] Claude Code MCP registration ────────────────────────────────────
echo -e "${YELLOW}[3/10] Registering with Claude Code...${NC}"
if command -v claude &>/dev/null; then
  claude mcp add specky -- npx -y specky-sdd 2>/dev/null \
    && echo -e "  ${GREEN}✓${NC} Claude Code: MCP registered" \
    || echo -e "  ${YELLOW}ℹ${NC} Claude Code: run manually: claude mcp add specky -- npx -y specky-sdd"
else
  echo -e "  ${YELLOW}ℹ${NC} Claude Code: not found (optional) — run: claude mcp add specky -- npx -y specky-sdd"
fi

# ─── [4/10] Agents → .github/agents/ (7 total) ──────────────────────────────
echo -e "${YELLOW}[4/10] Agents → .github/agents/ (7 agents)${NC}"
mkdir -p "$REPO_DIR/.github/agents"
cp "$SCRIPT_DIR/.github/agents/"*.md "$REPO_DIR/.github/agents/"
AGENT_COUNT=$(ls "$REPO_DIR/.github/agents/"*.md 2>/dev/null | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $AGENT_COUNT agents:"
for f in requirements-engineer.agent.md sdd-init.agent.md research-analyst.agent.md sdd-clarify.agent.md implementer.agent.md test-verifier.agent.md release-engineer.agent.md; do
  [ -f "$REPO_DIR/.github/agents/$f" ] \
    && echo -e "    ${CYAN}·${NC} $f" \
    || echo -e "    ${RED}✗${NC} MISSING: $f"
done

# ─── [5/10] Commands → .claude/commands/ (7 total) ──────────────────────────
echo -e "${YELLOW}[5/10] Commands → .claude/commands/ (7 commands)${NC}"
mkdir -p "$REPO_DIR/.claude/commands"
cp "$SCRIPT_DIR/.claude/commands/"*.md "$REPO_DIR/.claude/commands/"
CMD_COUNT=$(ls "$REPO_DIR/.claude/commands/"*.md 2>/dev/null | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $CMD_COUNT commands:"
for f in sdd-requirements.md sdd-init.md sdd-research.md sdd-clarify.md sdd-implement.md sdd-test.md sdd-release.md; do
  [ -f "$REPO_DIR/.claude/commands/$f" ] \
    && echo -e "    ${CYAN}·${NC} /sdd:$(basename $f .md | sed 's/sdd-//')" \
    || echo -e "    ${RED}✗${NC} MISSING: $f"
done

# ─── [6/10] Skills → .specky/skills/ (5 total, SHARED) ─────────────────────
echo -e "${YELLOW}[6/10] Skills → .specky/skills/ (5 skills, shared)${NC}"
for d in "$SCRIPT_DIR/.specky/skills/"*/; do
  s=$(basename "$d")
  mkdir -p "$REPO_DIR/.specky/skills/$s"
  cp "$d/SKILL.md" "$REPO_DIR/.specky/skills/$s/"
done
SKILL_COUNT=$(ls "$REPO_DIR/.specky/skills/" | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $SKILL_COUNT skills in .specky/skills/ (accessible by all platforms)"

# ─── [7/10] Hook scripts → .specky/hooks/ (10 total, SHARED) ───────────────
echo -e "${YELLOW}[7/10] Hook scripts → .specky/hooks/ (10 scripts, shared)${NC}"
mkdir -p "$REPO_DIR/.specky/hooks"
cp "$SCRIPT_DIR/.specky/hooks/"*.sh "$REPO_DIR/.specky/hooks/"
chmod +x "$REPO_DIR/.specky/hooks/"*.sh
# Also create GitHub Actions workflows
mkdir -p "$REPO_DIR/.github/workflows"
cp "$SCRIPT_DIR/.github/workflows/"*.yml "$REPO_DIR/.github/workflows/"
HOOK_COUNT=$(ls "$REPO_DIR/.specky/hooks/"*.sh 2>/dev/null | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $HOOK_COUNT scripts → .specky/hooks/ (BLOCKING: security-scan, release-gate)"
echo -e "  ${GREEN}✓${NC} 10 workflows → .github/workflows/ (CI/CD equivalents)"

# ─── [8/10] GitHub Actions workflows are already copied above ───────────────
echo -e "${YELLOW}[8/10] GitHub Actions → .github/workflows/ (already done in step 7)${NC}"
WF_COUNT=$(ls "$REPO_DIR/.github/workflows/"*.yml 2>/dev/null | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $WF_COUNT workflows confirmed"

# ─── [9/10] Hook config JSONs (3 platforms) ─────────────────────────────────
echo -e "${YELLOW}[9/10] Hook configs → 3 platform targets${NC}"

# 9a: Claude Code → .claude/settings.json
mkdir -p "$REPO_DIR/.claude"
if [ -f "$REPO_DIR/.claude/settings.json" ]; then
  # Backup existing settings
  cp "$REPO_DIR/.claude/settings.json" "$REPO_DIR/.claude/settings.json.bak"
  echo -e "  ${CYAN}ℹ${NC}  Backed up existing .claude/settings.json"
fi
cp "$SCRIPT_DIR/.claude/settings.json" "$REPO_DIR/.claude/settings.json"
echo -e "  ${GREEN}✓${NC} .claude/settings.json      (Claude Code hooks registered)"

# 9b: GitHub Copilot CLI/Cloud → .github/hooks/sdd-hooks.json
mkdir -p "$REPO_DIR/.github/hooks"
cp "$SCRIPT_DIR/.github/hooks/sdd-hooks.json" "$REPO_DIR/.github/hooks/sdd-hooks.json"
echo -e "  ${GREEN}✓${NC} .github/hooks/sdd-hooks.json (Copilot CLI + Cloud Agent hooks)"

# 9c: VS Code Copilot → .vscode/settings.json (MERGE, not replace)
if [ -f "$REPO_DIR/.vscode/settings.json" ]; then
  # Merge copilot hooks into existing VS Code settings using Python
  python3 - "$REPO_DIR/.vscode/settings.json" "$SCRIPT_DIR/.vscode/settings.json" << 'PYEOF'
import json, sys

existing_path = sys.argv[1]
new_path = sys.argv[2]

with open(existing_path) as f:
  existing = json.load(f)
with open(new_path) as f:
  new = json.load(f)

# Deep merge — new values win for overlapping keys
def deep_merge(base, override):
  result = dict(base)
  for k, v in override.items():
    if k in result and isinstance(result[k], dict) and isinstance(v, dict):
      result[k] = deep_merge(result[k], v)
    else:
      result[k] = v
  return result

merged = deep_merge(existing, new)
with open(existing_path, 'w') as f:
  json.dump(merged, f, indent=2)
PYEOF
  echo -e "  ${GREEN}✓${NC} .vscode/settings.json      (Copilot hooks merged into existing settings)"
else
  cp "$SCRIPT_DIR/.vscode/settings.json" "$REPO_DIR/.vscode/settings.json"
  echo -e "  ${GREEN}✓${NC} .vscode/settings.json      (created with Copilot hook config)"
fi

# ─── [9b/10] Prompts → dual-target (.claude/prompts/ + .github/prompts/) ───
echo -e "${YELLOW}[9b/10] Prompts → .claude/prompts/ + .github/prompts/ (19 prompts)${NC}"
mkdir -p "$REPO_DIR/.claude/prompts"
mkdir -p "$REPO_DIR/.github/prompts"
cp "$SCRIPT_DIR/.claude/prompts/"*.md "$REPO_DIR/.claude/prompts/"
cp "$SCRIPT_DIR/.github/prompts/"*.md "$REPO_DIR/.github/prompts/"
PROMPT_COUNT=$(ls "$REPO_DIR/.claude/prompts/"*.md 2>/dev/null | wc -l | tr -d ' ')
echo -e "  ${GREEN}✓${NC} $PROMPT_COUNT prompts → .claude/prompts/ (Claude Code: /specky:* slash commands)"
echo -e "  ${GREEN}✓${NC} $PROMPT_COUNT prompts → .github/prompts/ (Copilot: copiar e colar)"

# ─── [10/10] Project config + docs + verification ───────────────────────────
echo -e "${YELLOW}[10/10] Project config + docs + verification${NC}"

# Create .specky/config.yml
if [ ! -f "$REPO_DIR/.specky/config.yml" ]; then
  cp "$SCRIPT_DIR/.specky/config.yml" "$REPO_DIR/.specky/config.yml"
  echo -e "  ${GREEN}✓${NC} .specky/config.yml created"
else
  echo -e "  ${GREEN}✓${NC} .specky/config.yml exists"
fi

# Copy documentation files to project root
for doc in GETTING-STARTED.md INSTALL.md HOOKS-README.md Specky_Plugin_Ecosystem_Blueprint_v1_0_0_2026-04-13.md; do
  if [ -f "$SCRIPT_DIR/$doc" ]; then
    cp "$SCRIPT_DIR/$doc" "$REPO_DIR/$doc"
    echo -e "  ${GREEN}✓${NC} $doc → project root"
  fi
done

echo ""
echo -e "${YELLOW}  Verifying installation...${NC}"

T=0; P=0; FAIL=()

# 7 agents
for f in requirements-engineer.agent.md sdd-init.agent.md research-analyst.agent.md sdd-clarify.agent.md implementer.agent.md test-verifier.agent.md release-engineer.agent.md; do
  T=$((T+1))
  if [ -f "$REPO_DIR/.github/agents/$f" ]; then P=$((P+1)); else FAIL+=(".github/agents/$f"); fi
done

# 7 commands
for f in sdd-requirements.md sdd-init.md sdd-research.md sdd-clarify.md sdd-implement.md sdd-test.md sdd-release.md; do
  T=$((T+1))
  if [ -f "$REPO_DIR/.claude/commands/$f" ]; then P=$((P+1)); else FAIL+=(".claude/commands/$f"); fi
done

# 5 skills
for s in implementer test-verifier release-engineer research-analyst sdd-markdown-standard; do
  T=$((T+1))
  if [ -f "$REPO_DIR/.specky/skills/$s/SKILL.md" ]; then P=$((P+1)); else FAIL+=(".specky/skills/$s/SKILL.md"); fi
done

# 10 hook scripts (shared)
for h in spec-sync security-scan release-gate auto-checkpoint spec-quality task-tracer ears-validator drift-monitor cognitive-debt-alert metrics-dashboard; do
  T=$((T+1))
  if [ -f "$REPO_DIR/.specky/hooks/$h.sh" ]; then P=$((P+1)); else FAIL+=(".specky/hooks/$h.sh"); fi
done

# 10 GitHub Actions workflows
for h in spec-sync security-scan release-gate auto-checkpoint spec-quality task-tracer ears-validator drift-monitor cognitive-debt-alert metrics-dashboard; do
  T=$((T+1))
  if [ -f "$REPO_DIR/.github/workflows/$h.yml" ]; then P=$((P+1)); else FAIL+=(".github/workflows/$h.yml"); fi
done

# 3 hook configs
for f in ".vscode/mcp.json" ".claude/settings.json" ".github/hooks/sdd-hooks.json"; do
  T=$((T+1))
  if [ -f "$REPO_DIR/$f" ]; then P=$((P+1)); else FAIL+=("$f"); fi
done

# VS Code MCP + settings
T=$((T+1))
if [ -f "$REPO_DIR/.vscode/settings.json" ]; then P=$((P+1)); else FAIL+=(".vscode/settings.json"); fi

# .specky/config.yml
T=$((T+1))
if [ -f "$REPO_DIR/.specky/config.yml" ]; then P=$((P+1)); else FAIL+=(".specky/config.yml"); fi

# Prompts (spot-check 5 of 19)
for f in specky-greenfield.md specky-brownfield.md specky-research.md specky-debug-hook.md specky-pipeline-status.md; do
  T=$((T+1))
  if [ -f "$REPO_DIR/.claude/prompts/$f" ]; then P=$((P+1)); else FAIL+=(".claude/prompts/$f"); fi
done

# Docs in project root (all 4)
for doc in GETTING-STARTED.md INSTALL.md HOOKS-README.md Specky_Plugin_Ecosystem_Blueprint_v1_0_0_2026-04-13.md; do
  T=$((T+1))
  if [ -f "$REPO_DIR/$doc" ]; then P=$((P+1)); else FAIL+=("$doc"); fi
done

echo ""
if [ "$P" -eq "$T" ]; then
  echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║  ✅ All $T checks passed — Specky ecosystem ready!     ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
else
  echo -e "${YELLOW}⚠️  $P/$T checks passed${NC}"
  echo -e "${RED}Missing files:${NC}"
  for f in "${FAIL[@]}"; do echo -e "  ${RED}✗${NC} $f"; done
fi

echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Specky SDD Pipeline — Quick Reference${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e ""
echo -e "  ${CYAN}Claude Code (slash commands):${NC}"
echo -e "    /sdd:requirements   → Extract FRD + NFRD from problem statement"
echo -e "    /sdd:init           → Phase 0: Initialize pipeline + CONSTITUTION.md"
echo -e "    /sdd:research       → Phase 1: Scan codebase, run discovery"
echo -e "    /sdd:clarify        → Phase 2: Resolve ambiguities in spec"
echo -e "    /sdd:implement      → Phase 6: Generate implementation plan"
echo -e "    /sdd:test           → Phase 7: Verify test coverage"
echo -e "    /sdd:release        → Phase 9: Release checklist + PR"
echo -e ""
echo -e "  ${CYAN}VS Code + GitHub Copilot (@ agents):${NC}"
echo -e "    @requirements-engineer  → Pre-pipeline: FRD + NFRD"
echo -e "    @sdd-init               → Phase 0: Initialize pipeline"
echo -e "    @research-analyst       → Phase 1: Research + discovery"
echo -e "    @sdd-clarify            → Phase 2: Disambiguate requirements"
echo -e "    @implementer            → Phase 6: Implementation plan"
echo -e "    @test-verifier          → Phase 7: Test verification"
echo -e "    @release-engineer       → Phase 9: Release engineering"
echo -e ""
echo -e "  ${CYAN}Hook system:${NC}"
echo -e "    Scripts (shared):       .specky/hooks/*.sh"
echo -e "    Claude Code config:     .claude/settings.json"
echo -e "    Copilot CLI/Cloud:      .github/hooks/sdd-hooks.json"
echo -e "    VS Code Copilot:        .vscode/settings.json"
echo -e "    BLOCKING gates:         security-scan.sh, release-gate.sh"
echo -e ""
echo -e "  ${CYAN}Prompts (19 prontos para usar):${NC}"
echo -e "    Claude Code:            .claude/prompts/specky-*.md  (/specky:* slash commands)"
echo -e "    VS Code Copilot:        .github/prompts/specky-*.md  (copiar e colar no chat)"
echo -e "    Tipos:  greenfield · brownfield · migration · api"
echo -e "            research · clarify · specify · design · tasks · implement · verify · release"
echo -e "            from-figma · from-meeting · check-drift · resolve-conflict"
echo -e "            debug-hook · pipeline-status · reset-phase"
echo -e ""
echo -e "  ${CYAN}Documentation:${NC}"
echo -e "    GETTING-STARTED.md      Onboarding completo + todos os casos de uso"
echo -e "    INSTALL.md              Pipeline map completo"
echo -e "    HOOKS-README.md         3-layer hooks reference"
echo -e "    Specky_Plugin_Ecosystem_Blueprint.md  Complete blueprint"
echo -e ""
