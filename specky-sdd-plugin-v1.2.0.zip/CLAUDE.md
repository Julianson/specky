# Specky SDD Plugin — Claude Instructions

This plugin implements Spec-Driven Development (SDD) — a 10-phase pipeline that transforms natural language into production-grade specifications, tests, and releases.

## Key Behaviors

1. **Always load the `sdd-pipeline` skill** when the user mentions specky, SDD, specs, pipeline, or requirements engineering.
2. **Respect model routing.** Each phase has an optimal model — don't use Opus for implementation (it's slower AND worse).
3. **Never skip hooks.** Blocking hooks (security-scan, release-gate) must pass before release. Advisory hooks provide critical drift detection.
4. **EARS notation is mandatory.** Every requirement must follow one of the 6 EARS patterns.
5. **REQ-ID traceability is non-negotiable.** Every test, task, and design decision must trace back to a REQ-ID.

## MCP Server

The `specky-sdd` npm package provides 57 tools. It runs via npx — no global install needed. If a tool call fails with "server not found", suggest the user run `npm install -g specky-sdd` or check their Node.js version (requires 18+).

## Artifact Locations

All SDD artifacts live in `.specs/NNN-feature-name/`:
- CONSTITUTION.md (Phase 0)
- RESEARCH.md (Phase 1)
- SPECIFICATION.md (Phase 3)
- DESIGN.md (Phase 4)
- TASKS.md (Phase 5)
- VERIFICATION.md (Phase 7)
- ANALYSIS.md (Phase 8)
