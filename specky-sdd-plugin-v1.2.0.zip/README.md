# Specky SDD Plugin

**Spec-Driven Development pipeline for Claude Code, Cowork, and VS Code + GitHub Copilot.**

Transform natural language into production-grade specifications through a 10-phase pipeline with EARS-notation requirements, Mermaid architecture diagrams, sequenced task plans, quality gates with traceability matrices, and intelligent model routing.

## What This Plugin Does

Specky SDD gives you a complete software development pipeline that starts from an idea and takes it all the way to a verified, release-ready PR — with specifications, architecture, tests, and documentation generated along the way.

The pipeline has 10 phases, each backed by specialized agents and optimized model routing:

| Phase | Name | Agent | Model |
|-------|------|-------|-------|
| 0 | Init | `@sdd-init` | Haiku (scaffolding) |
| 1 | Research | `@research-analyst` | Sonnet (synthesis) |
| 2 | Clarify | `@sdd-clarify` | Opus (reasoning) |
| 3 | Specify | — | Opus (reasoning) |
| 4 | Design | — | Opus (reasoning) |
| 5 | Tasks | — | Sonnet (sequencing) |
| 6 | Implement | `@implementer` | Sonnet (iterative) |
| 7 | Verify | `@test-verifier` | Sonnet (pattern-matching) |
| 8 | Review | — | Opus (analysis) |
| 9 | Release | `@release-engineer` | Haiku (templates) |

## Components

### Commands (26 total)

**Core Pipeline (7):**
- `/specky-sdd:sdd-init` — Initialize pipeline for a new feature
- `/specky-sdd:sdd-requirements` — Analyze input, produce validated FRD + NFRD
- `/specky-sdd:sdd-research` — Scan codebase, import documents, produce RESEARCH.md
- `/specky-sdd:sdd-clarify` — Disambiguate requirements, validate EARS patterns
- `/specky-sdd:sdd-implement` — Generate implementation plan, checklists, test stubs
- `/specky-sdd:sdd-test` — Verify coverage, detect phantom completions
- `/specky-sdd:sdd-release` — Run release gates, generate docs, create PR

**Quick-Start Prompts (4):**
- `/specky-sdd:specky-greenfield` — New project from scratch
- `/specky-sdd:specky-brownfield` — Add SDD to existing codebase
- `/specky-sdd:specky-migration` — Plan a system migration
- `/specky-sdd:specky-api` — Design an API

**Phase Shortcuts (8):**
- `/specky-sdd:specky-research` through `/specky-sdd:specky-release`

**Special Cases (4):**
- `/specky-sdd:specky-from-figma` — Import Figma designs
- `/specky-sdd:specky-from-meeting` — Import meeting transcripts
- `/specky-sdd:specky-check-drift` — Check spec-code drift
- `/specky-sdd:specky-resolve-conflict` — Resolve spec conflicts

**Troubleshooting (3):**
- `/specky-sdd:specky-debug-hook` — Debug failing hooks
- `/specky-sdd:specky-pipeline-status` — Check pipeline status
- `/specky-sdd:specky-reset-phase` — Reset a phase

### Agents (7)

| Agent | Role | Model |
|-------|------|-------|
| `sdd-init` | Pipeline initialization | Haiku |
| `requirements-engineer` | FRD/NFRD generation | Opus |
| `research-analyst` | Technical research | Sonnet |
| `sdd-clarify` | Ambiguity resolution | Opus |
| `implementer` | Implementation scaffolding | Sonnet |
| `test-verifier` | Coverage verification | Sonnet |
| `release-engineer` | Release preparation | Haiku |

### Skills (6)

| Skill | Purpose |
|-------|---------|
| `sdd-pipeline` | Core pipeline knowledge, phases, EARS, model routing |
| `implementer` | Implementation plans, checklists, test stubs, IaC |
| `test-verifier` | Coverage gates, phantom detection, drift analysis |
| `release-engineer` | Blocking gates, docs, PR creation |
| `research-analyst` | Codebase scanning, discovery, ecosystem check |
| `sdd-markdown-standard` | Artifact formatting standard |

### Hooks (10)

**Blocking (exit 2 = stops execution):**
- `security-scan.sh` — OWASP + secrets scan before release
- `release-gate.sh` — VERIFICATION.md + ≥90% pass rate before PR

**Advisory (exit 0 = informational):**
- `spec-sync.sh` — Detect spec-code drift during implementation
- `auto-checkpoint.sh` — Snapshot spec artifacts on write
- `spec-quality.sh` — Validate specification quality
- `ears-validator.sh` — Check EARS pattern compliance
- `task-tracer.sh` — Detect tasks missing REQ-* traceability
- `drift-monitor.sh` — Monitor CONSTITUTION.md drift
- `cognitive-debt-alert.sh` — Alert on high LGTM-without-modification rate
- `metrics-dashboard.sh` — Remind to generate metrics dashboard

### MCP Server

Connects to the `specky-sdd` npm package (v3.2.0) which provides 57 tools across all 10 phases.

## Setup

The plugin auto-configures everything on install. The MCP server runs via npx — no global install needed.

**Requirements:**
- Node.js 18+ (for the specky-sdd MCP server)
- npm (comes with Node.js)

## Quick Start

**New project:**
```
/specky-sdd:specky-greenfield
```

**Existing codebase:**
```
/specky-sdd:specky-brownfield
```

**Check status:**
```
/specky-sdd:specky-pipeline-status
```

## EARS Notation

All requirements follow the EARS (Easy Approach to Requirements Syntax) patterns:

| Pattern | Format |
|---------|--------|
| Ubiquitous | The system shall... |
| Event-driven | When [event], the system shall... |
| State-driven | While [state], the system shall... |
| Optional | Where [condition], the system shall... |
| Unwanted | If [condition], then the system shall... |
| Complex | While [state], when [event], the system shall... |

## Model Routing

Cost-optimized model selection per phase based on task complexity:

- **Haiku 4.5** (0.33x cost): Scaffolding, templates, deterministic tasks (Phase 0, 9)
- **Sonnet 4.6** (1x cost): Synthesis, iteration, pattern-matching (Phase 1, 5, 6, 7)
- **Opus 4.6** (3x cost): Deep reasoning, ambiguity resolution, architecture (Phase 2, 3, 4, 8)

Extended thinking on Phase 6 (implementation) costs +43% and degrades quality -30% (arXiv:2502.08235).

## Dual-Target Parity

This plugin works natively in Claude Code and Cowork. For VS Code + GitHub Copilot parity, the v1.1.2 ecosystem installer (included separately) deploys equivalent `.github/agents/` and `.github/prompts/` files.

## References

- arXiv:2502.08235 — Extended thinking cost/quality analysis
- arXiv:2601.03878 — EARS quality and human-in-loop gates
- arXiv:2602.00180 — SDD traceability methodology
- arXiv:2602.20478 — Anti-context-collapse and artifact preservation
- arXiv:2603.22106 — Cognitive surrender measurement
- arXiv:2503.23278 — Security enforcement patterns
- arXiv:2507.09089 — AI productivity paradox

## License

MIT
