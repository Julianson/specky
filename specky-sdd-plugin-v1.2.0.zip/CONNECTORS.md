# Connectors

## How tool references work

Plugin files use `~~category` as a placeholder for whatever tool the user connects in that category. Plugins are tool-agnostic — they describe workflows in terms of categories rather than specific products.

## Connectors for this plugin

| Category | Placeholder | Included servers | Other options |
|----------|-------------|-----------------|---------------|
| Source control | `~~source control` | GitHub (via MCP) | GitLab, Bitbucket, Azure DevOps |
| Project tracker | `~~project tracker` | GitHub Issues | Linear, Asana, Jira, Azure Boards |
| Design tool | `~~design tool` | Figma (via MCP) | Sketch, Adobe XD |

## VS Code + GitHub Copilot Parity

This plugin is designed for Claude Code and Cowork. For VS Code + GitHub Copilot, the companion ecosystem installer (`specky-ecosystem-v1.1.2.zip`) deploys equivalent files:

| Plugin Component | VS Code + Copilot Equivalent |
|-----------------|------------------------------|
| `commands/*.md` | `.claude/commands/*.md` + `.github/prompts/*.md` |
| `agents/*.md` | `.github/agents/*.agent.md` |
| `skills/*/SKILL.md` | `.specky/skills/*/SKILL.md` |
| `hooks/hooks.json` | `.claude/settings.json` + `.github/hooks/sdd-hooks.json` + `.vscode/settings.json` |
| `.mcp.json` | `.vscode/mcp.json` |

Both targets share the same hook scripts in `hooks/scripts/` (plugin) or `.specky/hooks/` (ecosystem).
