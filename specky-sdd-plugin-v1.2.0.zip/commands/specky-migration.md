---
description: "Plan a migration with SDD pipeline"
---

# Plan a Migration with SDD Pipeline

I'm helping you plan a system migration using the Specky SDD pipeline. Please provide:

**Migration Details:**
- Source system: [SOURCE_SYSTEM]
- Target system: [TARGET_SYSTEM]
- Data constraints and dependencies: [DATA_CONSTRAINTS]
- Migration timeline: [TIMELINE]

I'll use the SDD pipeline to break down the migration into well-specified phases.
