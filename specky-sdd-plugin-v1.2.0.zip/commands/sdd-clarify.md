---
description: Disambiguate requirements and validate EARS
model: opus
argument-hint: [feature-number]
---

Run the clarification phase for the specified feature.

1. Read SPECIFICATION.md from `.specs/NNN-feature/`
2. Call `sdd_clarify` — returns up to 5 disambiguation questions targeting ambiguous or incomplete requirements
3. Present questions to the developer and wait for answers
4. Call `sdd_validate_ears` — validate all 6 EARS patterns:
   - Ubiquitous: The system shall...
   - Event-driven: When [event], the system shall...
   - State-driven: While [state], the system shall...
   - Optional: Where [condition], the system shall...
   - Unwanted: If [condition], then the system shall...
   - Complex: While [state], when [event], the system shall...
5. If EARS validation finds issues, suggest rewrites
6. If all resolved and EARS passes, suggest advancing to the next phase
7. If critical ambiguities remain, loop with remaining questions

$ARGUMENTS
