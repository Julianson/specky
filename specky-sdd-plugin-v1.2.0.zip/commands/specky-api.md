---
description: "Design an API with SDD pipeline"
---

# Design an API with SDD Pipeline

I'm helping you design an API using the Specky SDD pipeline. Please provide:

**API Design Details:**
- API name: [API_NAME]
- Endpoints needed: [ENDPOINTS_LIST]
- Authentication model: [AUTH_MODEL]
- Versioning strategy: [VERSIONING_APPROACH]

I'll guide you through the SDD specification and design phases for your API.
