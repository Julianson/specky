---
description: Scan codebase and produce RESEARCH.md
model: sonnet
argument-hint: [feature-number]
---

Load the `research-analyst` skill from this plugin.

Gather all context needed before specification begins.

1. Read CONSTITUTION.md for the feature from `.specs/`
2. If brownfield or modernization, call `sdd_scan_codebase` to detect tech stack
3. If external documents exist, call `sdd_import_document` or `sdd_import_transcript`
4. Call `sdd_discover` — present 7 structured discovery questions and wait for answers
5. Call `sdd_research` — investigate any technical unknowns
6. Call `sdd_check_ecosystem` — identify recommended MCP servers for the project
7. Produce RESEARCH.md with all findings
8. Suggest handoff to specification phase

$ARGUMENTS
