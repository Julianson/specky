---
description: "Reset an SDD phase"
---

# Reset an SDD Phase

I'm helping you reset a phase in your SDD pipeline. Please provide:

**Phase Reset Details:**
- Feature number: [FEATURE_NUMBER]
- Phase number (1-8): [PHASE_NUMBER]

I'll revert the specified phase to its initial state so you can restart or revise it.
