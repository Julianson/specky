---
description: Run release gates and create PR
model: haiku
argument-hint: [feature-number]
---

Load the `release-engineer` skill from this plugin.

Prepare the feature for delivery.

1. Verify ANALYSIS.md exists with gate decision = APPROVE
2. Verify VERIFICATION.md exists with pass rate ≥90%
3. Run blocking gates:
   - `security-scan.sh` — OWASP + secrets scan (BLOCKING: exit 2 = cannot proceed)
   - `release-gate.sh` — verification + pass rate check (BLOCKING: exit 2 = cannot proceed)
4. If either gate fails, explain exactly what failed and how to fix it. Do NOT proceed.
5. Call `sdd_generate_all_docs` — generate documentation suite in parallel
6. Call `sdd_create_pr` — generate PR payload for source control
7. Optionally call `sdd_export_work_items` — update external project trackers
8. Deliver release summary with all generated artifacts

$ARGUMENTS
