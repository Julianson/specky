---
description: "Start a greenfield project with SDD pipeline"
---

# Start a Greenfield Project with SDD Pipeline

I'm helping you start a brand new project using the Specky SDD (Specification-Driven Development) pipeline. Please provide the following information:

**Project Details:**
- Project name: [PROJECT_NAME]
- Project description: [BRIEF_DESCRIPTION]
- Technology stack: [STACK_TECHNOLOGIES]
- Development timeline: [TIMELINE_ESTIMATE]
- Compliance requirements: [COMPLIANCE_REQS]

Once you provide these details, I'll initialize your SDD pipeline with the research phase and set up the project structure.
