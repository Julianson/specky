---
description: "Run SDD design phase"
---

# Run SDD Design Phase

I'm running the design phase of the SDD pipeline. Please provide:

**Design Details:**
- Feature number: [FEATURE_NUMBER]

I'll create architecture diagrams and design documents that translate specifications into implementable designs.
