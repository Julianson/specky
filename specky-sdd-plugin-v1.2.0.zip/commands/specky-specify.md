---
description: "Run SDD specification phase"
---

# Run SDD Specification Phase

I'm running the specification phase of the SDD pipeline. Please provide:

**Specification Details:**
- Feature number: [FEATURE_NUMBER]

I'll create a detailed specification using EARS (Easy Approach to Requirements Syntax) validation to ensure clarity and completeness.
