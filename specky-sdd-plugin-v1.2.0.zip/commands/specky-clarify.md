---
description: "Run SDD clarification phase"
---

# Run SDD Clarification Phase

I'm running the clarification phase of the SDD pipeline. Please provide:

**Clarification Details:**
- Feature number: [FEATURE_NUMBER]

I'll use @sdd-clarify to resolve ambiguities, validate assumptions, and ensure all stakeholders have a shared understanding.
