---
description: "Run SDD task breakdown phase"
---

# Run SDD Task Breakdown Phase

I'm running the task breakdown phase of the SDD pipeline. Please provide:

**Task Breakdown Details:**
- Feature number: [FEATURE_NUMBER]

I'll break down the design into specific, trackable tasks with parallel work markers and dependency relationships.
