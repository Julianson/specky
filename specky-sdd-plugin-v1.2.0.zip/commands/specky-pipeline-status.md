---
description: "Check SDD pipeline status"
---

# Check SDD Pipeline Status

I'm retrieving the status of your SDD pipeline. Please provide:

**Status Check Details:**
- Feature number or "all": [FEATURE_NUMBER_OR_ALL]

I'll report the current phase, completion percentage, and any blocking issues in your pipeline.
