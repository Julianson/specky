---
description: "Check spec-code drift"
---

# Check Specification-Code Drift

I'm checking for divergence between your specification and current implementation. Please provide:

**Drift Analysis Details:**
- Feature number: [FEATURE_NUMBER]

I'll analyze the codebase against the specification and report any inconsistencies or deviations.
