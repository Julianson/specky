---
description: "Run SDD research phase"
---

# Run SDD Research Phase

I'm running the research phase of the SDD pipeline. Please provide:

**Research Details:**
- Feature number: [FEATURE_NUMBER]

I'll leverage the @research-analyst to gather requirements, understand constraints, and document initial findings for your feature.
