---
description: "Debug a failing SDD hook"
---

# Debug a Failing SDD Hook

I'm helping you debug a hook that's not working as expected. Please provide:

**Hook Debugging Details:**
- Hook name: [HOOK_NAME]
- Error message: [ERROR_MESSAGE]

I'll investigate the hook configuration and execution to identify and fix the issue.
