---
description: Verify test coverage and detect phantom completions
model: sonnet
argument-hint: [feature-number]
---

Load the `test-verifier` skill from this plugin.

Verify that the implementation satisfies the specification with evidence.

1. Verify TASKS.md and code files exist for the feature
2. Call `sdd_verify_tests` — parse results, map to REQ-IDs, build coverage report
3. Call `sdd_verify_tasks` — detect phantom completions (tasks marked done but tests failing)
4. Call `sdd_check_sync` — detect spec-code drift
5. Optionally call `sdd_validate_ears` — re-validate EARS integrity
6. Present verification report with gate decision (PASS or FAIL)

Gate criteria:
- Test pass rate ≥90%
- All P0 requirements have passing tests
- Zero phantom completions
- Spec-code drift ≤20%

$ARGUMENTS
