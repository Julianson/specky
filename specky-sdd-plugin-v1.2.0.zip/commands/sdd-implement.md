---
description: Generate implementation plan and test stubs
model: sonnet
argument-hint: [feature-number]
---

Load the `implementer` skill from this plugin.

Generate the complete implementation scaffold for the specified feature.

1. Verify TASKS.md and DESIGN.md exist in `.specs/NNN-feature/`
2. Call `sdd_implement` — generate ordered implementation plan (Foundation → Core → Integration → Polish)
3. Call `sdd_checklist` for security + testing domains (mandatory) plus any conditional NFR domains
4. Detect test framework from codebase, then call `sdd_generate_tests` — every test stub must include `// REQ-XXX` traceability
5. If EARS requirements contain invariants, call `sdd_generate_pbt` for property-based tests
6. If deployment architecture exists in DESIGN.md, call `sdd_generate_iac` and/or `sdd_generate_dockerfile`
7. Deliver implementation handoff summary with task count, test count, checklists, and infrastructure

Never enable extended thinking for implementation tools — it costs +43% and degrades quality -30% (arXiv:2502.08235).

$ARGUMENTS
