---
description: "Run SDD verification phase"
---

# Run SDD Verification Phase

I'm running the verification phase of the SDD pipeline. Please provide:

**Verification Details:**
- Feature number: [FEATURE_NUMBER]

I'll work with @test-verifier to create test cases, validate implementation against specifications, and ensure quality.
