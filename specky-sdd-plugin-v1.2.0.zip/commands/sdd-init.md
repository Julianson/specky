---
description: Initialize SDD pipeline for a new feature
model: haiku
argument-hint: [feature-name]
---

Initialize the SDD pipeline for the specified feature.

1. Check if `docs/requirements/` contains FRD.md and NFRD.md — if yes, read them for context
2. Call `sdd_init` with the feature name, project type, and any existing constraints
3. Verify CONSTITUTION.md was created in `.specs/NNN-feature-name/`
4. If the project has existing code (brownfield), call `sdd_scan_codebase` to detect the tech stack
5. Call `sdd_advance_phase` to move to Phase 1 (Research)
6. Present the created path and key CONSTITUTION.md fields to the developer
7. Suggest next step: `/specky-sdd:sdd-research` or `@research-analyst`

$ARGUMENTS
