---
description: "Add SDD to an existing codebase"
---

# Add SDD to an Existing Codebase

I'm helping you integrate the Specky SDD pipeline into your existing project. Please provide:

**Feature Details:**
- Feature name: [FEATURE_NAME]
- What you want to modernize: [MODERNIZATION_GOALS]
- Current tech stack or stated stack: [TECH_STACK]

I'll analyze your existing codebase and begin the SDD process for this feature.
