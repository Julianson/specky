---
description: "Resolve spec conflict"
---

# Resolve Specification Conflict

I'm helping you resolve a conflict in your specification. Please provide:

**Conflict Resolution Details:**
- Feature number: [FEATURE_NUMBER]
- Description of the conflict: [CONFLICT_DESCRIPTION]

I'll facilitate resolution by examining both perspectives and proposing aligned specifications.
