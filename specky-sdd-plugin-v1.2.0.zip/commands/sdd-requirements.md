---
description: Produce validated FRD and NFRD documents
model: opus
argument-hint: [project-name-or-description]
---

Load the `requirements-engineer` skill from this plugin.

Analyze the provided input and produce two validated requirement documents:
- `FRD_{ProjectName}_v1_0_0_{YYYY-MM-DD}.md`
- `NFRD_{ProjectName}_v1_0_0_{YYYY-MM-DD}.md`

Workflow:
1. Read existing files in workspace for context
2. Detect project type (greenfield, brownfield, migration, API, SaaS, etc.)
3. Run gap detector — ask max 3 questions for CRITICAL gaps only
4. Write FRD using EARS notation for every functional requirement
5. Write NFRD with measurable quality constraints
6. Run all 24 validation checks — fix every failure
7. Deliver Specky Handoff block confirming documents are ready for `sdd_init`

$ARGUMENTS
