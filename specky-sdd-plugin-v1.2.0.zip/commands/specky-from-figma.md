---
description: "Import Figma designs into SDD pipeline"
---

# Import Figma Designs into SDD Pipeline

I'm helping you import Figma designs into your SDD pipeline. Please provide:

**Figma Integration Details:**
- Figma URL: [FIGMA_URL]
- Feature to map to: [FEATURE_NUMBER]

I'll extract design specifications from your Figma file and map them to the appropriate SDD feature.
