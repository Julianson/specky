---
description: "Run SDD release phase"
---

# Run SDD Release Phase

I'm running the release phase of the SDD pipeline. Please provide:

**Release Details:**
- Feature number: [FEATURE_NUMBER]

I'll collaborate with @release-engineer to prepare documentation, manage deployments, and ensure smooth rollout.
